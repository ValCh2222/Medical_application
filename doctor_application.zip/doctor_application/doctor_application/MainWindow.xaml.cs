﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Npgsql;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using doctor_application.pages;
using System.Data;
using System.Windows.Controls.Primitives;
using doctor_application.windows;
using System.ComponentModel;
using System.Drawing;
using MaterialDesignThemes.Wpf;
using System.Collections;
using System.DirectoryServices.ActiveDirectory;
using doctor_application.Style;
using System.Xml.Linq;
using System.Net;
using doctor_application.Database;
using static System.Net.Mime.MediaTypeNames;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using System.IO;

namespace doctor_application
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  /// 
  public partial class MainWindow : Window
  {
    //public string username1 = "sazanovv2";
    //public string password1 = "sazanov_ac$53-";
    //public string username1 = "golovanova2";
    //public string password1 = "go?lov_12d";

    private Doctor_module doctor_Module1 = new Doctor_module();
    private Patients_Page Patients_Page = new Patients_Page();  

    private doctor_records_info Doctor_Records_Info = new doctor_records_info();

    public static string role;
    public static string connectionString;

    public MainWindow(string connectionstr) 
    {
 
      InitializeComponent();
      connectionString = connectionstr;
      profile_btn.Click += MyProfile;
      doctors_btn.Click += Doctors;
      recipes_doct_records_btn.Click += open_page_show_doctor_records;
      patients_btn.Click += Patients;
      exit_btn.Click += GoOutOfApp;

    }
    private void GoOutOfApp(object sender, RoutedEventArgs e)
    {
      Authorization authorization_window = new Authorization();
    authorization_window.Show();
      this.Close();
    }


    private void MyProfile(object sender, RoutedEventArgs e)
    {
    Profile profile = new Profile();


    frame_info_patient.Navigate(profile);

      Doctor_module doctor_Module = new Doctor_module();
      string role = doctor_Module.GetType_Doctor(username_txt.Text);
    }

    private void Doctors(object sender, RoutedEventArgs e)
    {       
      Doctors doctors2 = new Doctors();
      doctors2.Get_All_Doctors();
      frame_info_patient.Navigate(doctors2);
      
    }

    private void Patients(object sender, RoutedEventArgs e)
    {
      Patients_Page.Get_All_Patients();
      frame_info_patient.Navigate(Patients_Page);
     
    }

   
    private void open_page_show_doctor_records(object sender, RoutedEventArgs e)
    {
      Doctor_Records_Info.Show_Doc_Records();
      frame_info_patient.Navigate(Doctor_Records_Info);
      
    }

    


  }

}

