﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using doctor_application.windows;
using Npgsql;


namespace doctor_application.Database
{
    public class UserConnector
    {
    //public string username1 = "sazanovv";
    //public string password1 = "sazanov_ac$53-";
    public string role = "";
   // public string conn_str = window1.connectionString;
   // public static string _connectionStr = $"Server=127.0.0.1;User Id=sazanovv2;" +
       //   $"Password=sazanov_ac$53-;Database=cursovaya;"; 
    private NpgsqlConnection _connection = new NpgsqlConnection();
   
    public  void SetRole(string f)
    {
      
      role = f;
    }
    public NpgsqlConnection GetConnection()
    {
      _connection.ConnectionString = MainWindow.connectionString;
      return _connection; 
    }
   
    public void OpenConnection()
    {
      try
      {
        _connection.Open();
      }
      catch (NpgsqlException e)
      {

        MessageBox.Show(e.Message);
      }
    }

    public void CloseConnection()
    {
      try
      {
        _connection.Close();
      }
      catch (NpgsqlException e)
      {
        MessageBox.Show(e.Message);
      }
    }

    

  }
}
