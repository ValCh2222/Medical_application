﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
   public  class AuthentificationDoc
    {
     public int Id_identif_doc { get; set; }
    public string Seria { get; set; }
    public string Number_ident_doc { get; set; }
    public string Validity_period { get; set; }

    public string Type_Document { get; set; }
    public int Patient_id;

    public AuthentificationDoc(int id_doc, string seria, string num, string per, string type, int pat_id) 
    {
      Id_identif_doc= id_doc;
      Seria= seria;
      Number_ident_doc= num;
      Validity_period= per;
      Type_Document= type;
      Patient_id= pat_id;
    }

    public AuthentificationDoc() { }

  }
}
