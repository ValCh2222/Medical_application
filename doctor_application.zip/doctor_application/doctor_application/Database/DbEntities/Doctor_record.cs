﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
    class Doctor_record
    {
    public int Id { get; set; }
    public string Complaints { get; set; }

    public string Patient_Username { get; set; }
    public string Doctor_Username { get; set; }
    public string Date_Visiting { get; set; }
    public string Complication { get;}
    public int Medcard_number { get; set; }
    public int Doctor_id { get; set; }

    public string Pat_sex { get; set; }
    


    public Doctor_record(int id, string date, string complaints, string complications , int medcard_num, 
      int id_doctor, string s, string doctor_us)
    {
      Id = id;
      Date_Visiting= date;
      Complaints = complaints;
      Complication= complications;
      Medcard_number= medcard_num;
      Doctor_id= id_doctor;
      Pat_sex= s;
      Doctor_Username = doctor_us;

    }

    public Doctor_record(string date , string complaints, string complications , int med_num, int  id_doctor) 
    {
      Date_Visiting = date;
      Complaints = complaints;
      Complication= complications;
      Medcard_number= med_num;
      Doctor_id= id_doctor;
    
 
    }

    public Doctor_record(int id, string date, string doc, string pat, string s)
    {
      Id= id;
      Date_Visiting = date;
      Doctor_Username = doc;
      Pat_sex= s;
      Patient_Username = pat;



    }


    public Doctor_record(string date, string complaints, string complications, string username)
    {
      Date_Visiting = date;
      Complaints = complaints;
      Complication= complications;  
      Patient_Username= username;

    }

  }
}
