﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
   public class Doctor
    { 
    public int Doctor_id { get; }
    public string First_name { get; }
    public string Middle_name { get; }
    public string Second_name { get; }
    public int Expirience { get; }
    public string Education { get; }
    public string Username { get; }
    public int Specialization_id { get; }

    public string Name_specialization { get; }


    public Doctor(int doctor_id, string doctor_username,string  first_name, string middle_name, string second_name, int expirience, string education,
       int specialization_id)
    {
      Doctor_id = doctor_id;
     
      First_name = first_name;
      Middle_name = middle_name;
      Second_name = second_name;
      Expirience = expirience;
      Education = education;
      Username = doctor_username;
      Specialization_id = specialization_id;
    }

    public Doctor() { }

    public Doctor(string username, string first_name, string middle_name, string second_name, int expirience, string name_spec)
    {
      First_name = first_name;
      Middle_name = middle_name;
      Second_name = second_name;
      Expirience = expirience;
      Username = username;
      Name_specialization = name_spec;
    }

    

    public Doctor(string username, string first_name, string middle_name, string second_name, int expirience, string education, string specialization_id)
    {
      First_name = first_name;
      Middle_name = middle_name;
      Second_name = second_name;
      Expirience = expirience;
      Username = username;
      Education= education;
      Name_specialization = specialization_id;
    }
  }
}
