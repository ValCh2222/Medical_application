﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
    public class Patient
    {
    public int Patient_id { get; set; }
    public string First_name { get; set; }
    public string Middle_name { get; set; }
    public string Second_name { get; set; }

    public string Date_Birth { get; set; } 
    public string Patient_sex { get; set; }
    public string Phone_number { get; set; }

    public string Blood_group { get; set; }
    public string Rezus_factor { get; set; }
    public string Group_health { get; set; }
    public string Grazdanstvo { get; set; }
    public string Username { get; set; }
    public int Number_Medcard { get; set; }
    public string Allergy { get; set; }
    public string Disability { get; set; }
    public string Lgota { get; set; }
    public string Snils { get; set; }


    public Patient(int patient_id, string first_name, string middle_name, string second_name, string date_Birth, string patient_sex, string phone_number, string blood_group, string rezus_factor, string group_health, string grazdanstvo,string username, int number_Medcard, string allergy, string disability, string lgota, string snils)
        {
            Patient_id = patient_id;
            First_name = first_name;
            Middle_name = middle_name;
            Second_name = second_name;
            Date_Birth = date_Birth;
            Patient_sex = patient_sex;
            Phone_number = phone_number;
            Blood_group = blood_group;
            Rezus_factor = rezus_factor;
            Group_health = group_health;
            Grazdanstvo = grazdanstvo;
            Number_Medcard = number_Medcard;
            Allergy = allergy;
            Disability = disability;
            Lgota = lgota;
            Snils = snils;
            Username = username;
        }

        public Patient() { }

    public Patient(string username, string first_name, string middle_name, string second_name, int patient_id, string date_Birth,
      string patient_sex, string phone_number, string blood_group , string rezus_factor, string group_health, string grazdanstvo,
      int number_Medcard, string allergy, string snilis,string dis, string lgota)
    {
      First_name = first_name;
      Username = username;
      Second_name = second_name;
      Middle_name= middle_name;
      Patient_id = patient_id;
      Date_Birth = date_Birth;
      Patient_sex = patient_sex;
      Phone_number = phone_number;
      Blood_group = blood_group;
      Rezus_factor = rezus_factor;
      Group_health = group_health;
      Grazdanstvo = grazdanstvo;
      Number_Medcard = number_Medcard;
      Allergy = allergy;
      Snils = snilis;
      Disability = dis;
        Lgota = lgota;
    }

  }
}
