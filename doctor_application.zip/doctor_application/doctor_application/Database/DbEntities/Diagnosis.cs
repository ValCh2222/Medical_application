﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
    public class Diagnosis
    {
    public int Id_Doc_Record { get; set; }
    public string Firstly_repeatedly { get; set; }  
    public string Main_disease { get; set; }
    public string Related_disease { get; set; }


    public Diagnosis(string firstly_repeatedly, string main_disease, string related_disease)
        {         
            Firstly_repeatedly = firstly_repeatedly;
            Main_disease = main_disease;
            Related_disease = related_disease;
        }
    }
}
