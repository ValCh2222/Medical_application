﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
    public class FullInfoDocRecord
    {
    public string FIO_patient { get; }
    public string Date_Visiting { get; }
    public string Complaints { get; }
    public string Complication { get; }
    public string Anamnez { get; }
    public string Cause { get; }

    public string Main_Disease { get; }
    public string Second_Disease { get; }

    public string Firstly_Sec { get; }
    public string Drug { get; }
    public string Drug_Usage { get; }
    public string Drug_Dose { get; }

    public string Enum_Dose { get; }
    public string Drug_Recipe { get; }
    public string Drug_Dose_Recipe { get; }
    public string Drug_Way_Using_Recipe { get; }
    public string Dates_Recipe { get; }
    public string Drug_enum_Dose_Recipe { get; }


    public FullInfoDocRecord(string fIO_patient, string date_Visiting, string complaints, string complication, string anamnez, string cause, string main_Disease, string second_Disease, string firstly_Sec, string drug, string drug_Usage, string drug_Dose, string enum_Dose, string drug_Recipe, string drug_Dose_Recipe, string drug_Way_Using_Recipe, string dates_Recipe, string drug_enum_Dose_Recipe)
        {
            FIO_patient = fIO_patient;
            Date_Visiting = date_Visiting;
            Complaints = complaints;
            Complication = complication;
            Anamnez = anamnez;
            Cause = cause;
            Main_Disease = main_Disease;
            Second_Disease = second_Disease;
            Firstly_Sec = firstly_Sec;
            Drug = drug;
            Drug_Usage = drug_Usage;
            Drug_Dose = drug_Dose;
            Enum_Dose = enum_Dose;
            Drug_Recipe = drug_Recipe;
            Drug_Dose_Recipe = drug_Dose_Recipe;
            Drug_Way_Using_Recipe = drug_Way_Using_Recipe;
            Dates_Recipe = dates_Recipe;
            Drug_enum_Dose_Recipe = drug_enum_Dose_Recipe;
        }
    public FullInfoDocRecord() { }
    }
}
