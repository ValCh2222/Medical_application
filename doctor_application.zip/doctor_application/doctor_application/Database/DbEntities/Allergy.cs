﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
    class Allergy
    {
    public string Allergy_Name { get; }
    public Allergy(string name)
    {
      Allergy_Name = name;
    }

  }
}
