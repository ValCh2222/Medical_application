﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
    public class Sickness
    {
    public string Anamnes { get; set; } 
      public string Cause {get;set;}

    public Sickness(string anamnes, string cause) 
    {
      Anamnes = anamnes;
      Cause = cause;
    }
  }
}
