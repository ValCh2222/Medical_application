﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
    public class PolisOMS
    {
   public int Oms_id { get; set; }
    public string Seria { get; set; }
    public string Number { get; set; }
    public string DateEnding { get; set; }
    public string Insurance_organization_name { get; set; }
    public int Patient_id { get; set; }

    public PolisOMS(int oms_id, string seria, string number, string dateEnding, string insurance_organization_name, int patient_id)
        {
            Oms_id = oms_id;
            Seria = seria;
            Number = number;
            DateEnding = dateEnding;
            Insurance_organization_name = insurance_organization_name;
            Patient_id = patient_id;
        }

    public PolisOMS() { }
    }
}
