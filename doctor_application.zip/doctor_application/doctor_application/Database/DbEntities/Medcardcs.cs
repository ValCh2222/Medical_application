﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
    internal class Medcardcs
    {
    public int Number_medcard { get; set; }
    public int Number_patient { get; set; }
    public string Date_Creation { get; set; }

    public Medcardcs(int nummed, int numPat, string date) {
    Number_medcard= nummed;
      Number_patient = numPat;
      Date_Creation = date;
    }
    }
}
