﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
    public class Specialization
    {
    
    public string Specialization_Name { get; }

    public Specialization(string specialization_Name)
        {
            
            Specialization_Name = specialization_Name;
        }
    }
}
