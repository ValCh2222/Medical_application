﻿using System;
using System.Collections.Generic;
using System.IO.Packaging;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
    internal class AgreementDoc
    {
    public string Name_med_org { get; set; }
    public string Date_agreement { get; set; }
    public string Patient_id { get; set; }
    public AgreementDoc(string name_med_org, string date_)
    {
      Name_med_org= name_med_org;
      Date_agreement= date_;
    }
    }
}
