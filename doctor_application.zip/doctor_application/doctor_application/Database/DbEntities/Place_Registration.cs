﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doctor_application.Database.DbEntities
{
    public class Place_Registration
    {

    public string Country { get; set; }

    public string Subiect { get; set; }

    public string District { get; set; }

    public string City { get; set; }

    public string Locality { get; set; }
    public string Street { get; set; }

    public string House_Number { get; set; }


    public string Flat_number { get; set; }

    public Place_Registration(string country, string subiect, string district, string city, string locality, string street, string house_Number, string flat_number)
        {
            Country = country;
            Subiect = subiect;
            District = district;
            City = city;
            Locality = locality;
            Street = street;
            House_Number = house_Number;
            Flat_number = flat_number;
        }

    public Place_Registration() { } 
    }
}
