﻿using doctor_application.Database.DbEntities;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using System.Runtime.CompilerServices;
using NpgsqlTypes;

namespace doctor_application.Database.DbModules
{
    class LgotaDBModule
    {
    public List<String> GetLgotaList()
    {
      List<String> lgotas = new List<String>();
      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = "SELECT name_lgota FROM lgota ;";
      //int id, string date, string complaints, string complications , int medcard_num, int id_doctor
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());

      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          lgotas.Add(
              reader["name_lgota"].ToString());



        }
        sqlConnector.CloseConnection();
      }
      
      catch (Exception e)
      {
       // MessageBox.Show(e.Message);
      }

      return lgotas;
    }


 
  }

}

