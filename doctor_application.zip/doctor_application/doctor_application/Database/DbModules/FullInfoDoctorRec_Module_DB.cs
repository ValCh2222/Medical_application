﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using Npgsql;
using NpgsqlTypes;

namespace doctor_application.Database.DbModules
{
    class FullInfoDoctorRec_Module_DB
    {

    public FullInfoDocRecord GetFullInfo(int num_Rec)
    {
      FullInfoDocRecord full = new FullInfoDocRecord();
      List<Doctor_record> doc_records = new List<Doctor_record>();
      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = "";
      if (MainWindow.role =="glavvrach")
        {
        sqlCommand = "SELECT * FROM all_records_full_info_glavvrach where id_doctor_record = @num ;";
      }
      else
      {
        sqlCommand = "SELECT * FROM all_records_full_info_doctor where id_doctor_record = @num ;";
      }
    

      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("num", NpgsqlDbType.Integer, num_Rec);

      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
         FullInfoDocRecord fullInfoDocRecord1 = new FullInfoDocRecord(

              reader["fio_pat"].ToString(),
              reader["date_visiting"].ToString(),
              reader["complaints"].ToString(),
              reader["complication"].ToString(),
              reader["anamnez"].ToString(),
               reader["cause"].ToString(),
               reader["main_disease"].ToString(),
               reader["related_diseases"].ToString(),
              reader["firstly"].ToString(),
               reader["drug"].ToString(),
               reader["way_using"].ToString(),
               reader["dose_drug"].ToString(),
               reader["drug_enum"].ToString(),
               reader["recipt_drug"].ToString(),
               reader["recipt_dose_drug"].ToString(),
               reader["recipt_way_using"].ToString(),
               (reader["date_rec"].ToString() + "-" + reader["valid_pr"].ToString()),
               reader["recip_enum"].ToString()


          ) ;
          return fullInfoDocRecord1;
        }
        sqlConnector.CloseConnection();
      }
      catch (Exception e)
      {
        //MessageBox.Show(e.Message);
        return full;
      }

      return full;
    }
    }


}
