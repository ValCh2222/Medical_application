﻿using MaterialDesignThemes.Wpf;
using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace doctor_application.Database.DbModules
{
  internal class MedcardModule
  {
    public bool CreateMedcardPatientCreation(string username)
    {
      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = "INSERT INTO medcard(patient_id, date_creation) VALUES ((SELECT patient_id FROM patient  WHERE username  =@username), NOW());";

      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("username", NpgsqlDbType.Text, username);
      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        sqlConnector.CloseConnection();
        return true;
      }

      catch (Exception e)
      {
       // MessageBox.Show(e.Message);
        return false;
      }

    }
  }
  }
