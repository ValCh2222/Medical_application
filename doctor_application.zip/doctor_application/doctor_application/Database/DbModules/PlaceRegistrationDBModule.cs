﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using doctor_application.pages;
using Npgsql;
using NpgsqlTypes;

namespace doctor_application.Database.DbModules
{
    class PlaceRegistrationDBModule
    {
      public string GetPlaceRegPatient(Patient p)
    {
      string address = "";
      UserConnector userConnector = new UserConnector();  
      string sqlCommand = "select * from place_registration where  patient_id = @id;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("id", NpgsqlDbType.Integer, p.Patient_id);

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          address += "страна:  ";
          address += reader.GetString(1);
          address += " субъект:  ";
          address += reader.GetString(2);
          address += " район:  ";
          address += reader.GetString(3);
          address += " город:  ";
          address += reader.GetString(4);
          address += " местность:  ";
          address += reader.GetString(5);
          address += " улица:  ";
          address += reader.GetString(6);
          address += " дом: ";
          address += reader.GetString(7);
          address += " квартира: ";
          address += reader.GetInt32(8).ToString();
         
        }
        
        }
      catch (Exception ex) { }
      return address;
      }


    public Place_Registration GetPlaceRegPatientPlace(int a)
    {
      Place_Registration _Registration = new Place_Registration();
      UserConnector userConnector = new UserConnector();
      string sqlCommand = "select * from place_registration where  patient_id = @id;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("id", NpgsqlDbType.Integer, a);

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
         
          _Registration.Country= reader["country"].ToString();
        _Registration.Subiect= reader.GetString(2);
          _Registration.District =reader.GetString(3);
          _Registration.City= reader.GetString(4);
          _Registration.Locality= reader.GetString(5);
          _Registration.Street= reader.GetString(6);
          _Registration.House_Number= reader.GetString(7);
         _Registration.Flat_number= reader.GetString(8).ToString();

        }

      }
      catch (Exception ex) {/* MessageBox.Show(ex.Message); */}
      return _Registration;
    }

    //сначала создаём место регистрации, потом присваиваем пациенту 
    public void CreatePlaceRegPatient(Place_Registration place_, string username)
    {
      //call createplaceregistrationpatient('usernm', 'Россия', 'Москва', '-', 'Москва',
						//		   'ЗАО', 'летняя', '189', 40);
      UserConnector userConnector = new UserConnector();
      string sqlCommand = "insert into place_registration(country, subiect, district, city, locality, street, house_number, flat_number," +
        " patient_id) values (@country, @subiect, @district,@city,@locality ,@street,@house_number,@flat_number, " +
        " (SELECT patient_id FROM patient  WHERE username  =@username));";
      
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("username", NpgsqlDbType.Text, username);
      command.Parameters.AddWithValue("country", NpgsqlDbType.Text, place_.Country);
      command.Parameters.AddWithValue("subiect", NpgsqlDbType.Text, place_.Subiect);
      command.Parameters.AddWithValue("district", NpgsqlDbType.Text, place_.District);
      command.Parameters.AddWithValue("city", NpgsqlDbType.Text, place_.City);
      command.Parameters.AddWithValue("locality", NpgsqlDbType.Text, place_.Locality);
      command.Parameters.AddWithValue("street", NpgsqlDbType.Text, place_.Street);
      command.Parameters.AddWithValue("house_number", NpgsqlDbType.Text, place_.House_Number.ToString());
      command.Parameters.AddWithValue("flat_number", NpgsqlDbType.Integer,int.Parse(place_.Flat_number));
    


      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        userConnector.CloseConnection();
      }
      catch (NpgsqlException e)
      {
       // MessageBox.Show("place reg problem - "+e.Message);
      }

    }


    public void EditPlaceRegPatient(int patient_id,string _country, string _subiect,string _district ,
       string _city ,
          string _locality , string _street , string _house_number  , int  _flat )
    {

      UserConnector userConnector = new UserConnector();
      string sqlCommand = "call updateplaceregistrationpatient(@patient_id, @country, @subiect, @district, @city, @locality, @street," +
        "@house_number, @flat_number)";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("country", NpgsqlDbType.Text, _country);
      command.Parameters.AddWithValue("subiect", NpgsqlDbType.Text, _subiect);
      command.Parameters.AddWithValue("district", NpgsqlDbType.Text, _district);
      command.Parameters.AddWithValue("city", NpgsqlDbType.Text, _city);
      command.Parameters.AddWithValue("locality", NpgsqlDbType.Text, _locality);
      command.Parameters.AddWithValue("street", NpgsqlDbType.Text, _street);
      command.Parameters.AddWithValue("house_number", NpgsqlDbType.Text, _house_number);
      command.Parameters.AddWithValue("flat_number", NpgsqlDbType.Text, _flat.ToString());
      command.Parameters.AddWithValue("patient_id", NpgsqlDbType.Integer, patient_id);


      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        userConnector.CloseConnection();
        MessageBox.Show("registration is ready");
      }
      catch (Exception e)
      {
       // MessageBox.Show(e.Message);
      }

    }


    public void CreatePlaceRegPatientCREATION(Place_Registration place_, string username)
    {

      UserConnector userConnector = new UserConnector();
      string sqlCommand = "insert into place_registration(country, subiect, district, city, locality, street, house_number, flat_number," +
        " patient_id) values (@country, @subiect, @district,@city,@locality ,@street,@house_number,@flat_number, " +
        " (SELECT patient_id FROM patient  WHERE username  =@username));";

      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("username", NpgsqlDbType.Text, username);
      command.Parameters.AddWithValue("country", NpgsqlDbType.Text, place_.Country);
      command.Parameters.AddWithValue("subiect", NpgsqlDbType.Text, place_.Subiect);
      command.Parameters.AddWithValue("district", NpgsqlDbType.Text, place_.District);
      command.Parameters.AddWithValue("city", NpgsqlDbType.Text, place_.City);
      command.Parameters.AddWithValue("locality", NpgsqlDbType.Text, place_.Locality);
      command.Parameters.AddWithValue("street", NpgsqlDbType.Text, place_.Street);
      command.Parameters.AddWithValue("house_number", NpgsqlDbType.Text, place_.House_Number.ToString());
      command.Parameters.AddWithValue("flat_number", NpgsqlDbType.Integer, int.Parse(place_.Flat_number));

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        userConnector.CloseConnection();
      }
      catch (Exception e)
      {
        //MessageBox.Show(e.Message);
      }

    }
  }

 
}

