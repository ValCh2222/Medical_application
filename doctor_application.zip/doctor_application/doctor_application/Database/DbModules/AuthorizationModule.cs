﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Navigation;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using Npgsql;
using NpgsqlTypes;

namespace doctor_application.Database.DbModules
{
    class AuthorizationModule
    {
    AuthConnection authConnection = new AuthConnection();



    public bool CheckAuthorization(string username, string password)
    {
      bool res = false;
      string sqlCommand = "select check_authorization_doc(@us, @ps);";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, authConnection.GetConnection());
      command.Parameters.AddWithValue("us", NpgsqlDbType.Text, username); 
      command.Parameters.AddWithValue("ps", NpgsqlDbType.Text, password);


      try
      {
        authConnection.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        while(reader.Read()) { res = reader.GetBoolean(0); return res; }
      }
      catch(Exception ex) { return false; }
      return res;
    }

   

  }
}
