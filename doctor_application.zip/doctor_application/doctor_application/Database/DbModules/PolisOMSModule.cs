﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using Npgsql;
using NpgsqlTypes;

namespace doctor_application.Database.DbModules
{
    class PolisOMSModule
    {
    private UserConnector userConnector = new UserConnector();
    public PolisOMS  GetOMSPatient(Patient p)
    {
      PolisOMS polisOMS = new PolisOMS();
      string address = "";
      UserConnector userConnector = new UserConnector();
      string sqlCommand = "select * from polis_oms where  patient_id = @id;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("id", NpgsqlDbType.Integer, p.Patient_id);

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          polisOMS.Seria = reader["seria"].ToString();
          polisOMS.Number = reader["number_oms"].ToString();
          polisOMS.Insurance_organization_name = reader["insurance_organization_name"].ToString();
          polisOMS.Oms_id = int.Parse(reader["oms_id"].ToString());
          polisOMS.DateEnding = reader["date_ending"].ToString();
          polisOMS.Patient_id = int.Parse(reader["patient_id"].ToString()) ;
             
        }

      }
      catch (Exception ex) { }
      return polisOMS;
    }

    public string GetNumSeriaOMS(Patient p)
    {
      string polis = "";
      UserConnector userConnector = new UserConnector();
      string sqlCommand = "select * from polis_oms where  patient_id = @id;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("id", NpgsqlDbType.Integer, p.Patient_id);

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          polis += reader["seria"].ToString();
          polis += " - ";
          polis +=  reader["number_oms"].ToString();
        }

      }
      catch (Exception ex) { }
      return polis;
    }

    public bool CreateOMSPatientCreation(string username, string seria, string number )
    {
      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = "insert into polis_oms(seria, number_oms, patient_id )values (@seria, @number_oms, (SELECT patient_id FROM patient  WHERE username  =@username));";
      //int id, string date, string complaints, string complications , int medcard_num, int id_doctor
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("seria", NpgsqlDbType.Text, seria);
      command.Parameters.AddWithValue("number_oms", NpgsqlDbType.Text, number);
      command.Parameters.AddWithValue("username", NpgsqlDbType.Text, username);
      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        sqlConnector.CloseConnection();
        return true;
      }

      catch (Exception e)
      {
      //  MessageBox.Show("oms creation problem:" + e.Message);
        return false;
      }


    }

  }
}
