﻿using doctor_application.Database.DbEntities;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;

namespace doctor_application.Database.DbModules
{
    public  class SpecializaitonsModule
    {
    public List<Specialization> GetSpecializationListt()
    {
      List<Specialization> specialities = new List<Specialization>();
      UserConnector sqlConnector = new UserConnector();

      const string sqlCommand = "select * from get_all_specializations;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());

      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          specialities.Add(new Specialization(
             
              reader["name"].ToString()
          ));
        }
        sqlConnector.CloseConnection();
      }
      catch (Exception e)
      {
        //MessageBox.Show(e.Message);
      }

      return specialities;
    }
  }
}
