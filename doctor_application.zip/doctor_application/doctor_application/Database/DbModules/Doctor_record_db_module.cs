﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using doctor_application.pages;
using doctor_application.windows;
using Npgsql;
using NpgsqlTypes;

namespace doctor_application.Database.DbModules
{
  class Doctor_record_db_module
  {
    public int num = 0;

    public List<Doctor_record> GetDoctorRecordsList()
    {
      List<Doctor_record> doc_records = new List<Doctor_record>();
      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = " ";

      if (MainWindow.role == "glavvrach")
      {
        sqlCommand = "SELECT * FROM all_records_full_info_glavvrach ;";
      }
      else
      {
        sqlCommand = "SELECT * FROM all_records_full_info_doctor ;";
      }


      //int id, string date, string complaints, string complications , int medcard_num, int id_doctor
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());

      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          doc_records.Add(new Doctor_record(

              int.Parse(reader["id_doctor_record"].ToString()),
              reader["date_visiting"].ToString(),
              reader["doc_username"].ToString(),
              reader["username_patient"].ToString(),
              reader["patient_sex"].ToString()


          ));
        }
        sqlConnector.CloseConnection();
      }
      catch (Exception e)
      {
        MessageBox.Show(e.Message);
      }

      return doc_records;
    }


    public List<Doctor_record> GetPatientDoctorRecords(string user)
    {
      List<Doctor_record> doc_records = new List<Doctor_record>();
      UserConnector sqlConnector = new UserConnector();

      string sqlCommand = "";

      sqlCommand =
      "   select id_doctor_record, date_visiting, (select username from doctor  where id_doctor= doctor_record.id_doctor) as doc_username," +
      " (select username from patient where patient_id = " +
      "  (select patient_id from medcard where number_medcard = doctor_record.number_medcard)) as username_patient," +
      " (select sex from patient where patient_id = " +
      " (select patient_id from medcard where number_medcard = doctor_record.number_medcard)) as patient_sex" +
      " from doctor_record where (select username from patient where patient_id = " +
      " (select patient_id from medcard where number_medcard = doctor_record.number_medcard))=@usernm";


      //int id, string date, string complaints, string complications , int medcard_num, int id_doctor
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("usernm", NpgsqlDbType.Text, user);

      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          doc_records.Add(new Doctor_record(

              int.Parse(reader["id_doctor_record"].ToString()),
              reader["date_visiting"].ToString(),
              reader["doc_username"].ToString(),
              reader["username_patient"].ToString(),
              reader["patient_sex"].ToString()


          ));
        }
        sqlConnector.CloseConnection();
      }
      catch (Exception e)
      {
       // MessageBox.Show(e.Message);
      }

      return doc_records;
    }


    public void GetMyRecords()
    {
 //     //SELECT date_visiting,id_doctor_record
	//, 
	//(select username from patient where(patient_id =
 //     (select medcard.patient_id from medcard where medcard.patient_id= doctor_record.number_medcard)))

 //           as patient_username,
	//(select sex from patient where(patient_id =
 //     (select medcard.patient_id from medcard where medcard.patient_id= doctor_record.number_medcard)))

 //           as patient_sex ,
	//	current_user as doc_username

 // FROM doctor_record
    }
    public void CreateDoctorRecord(Doctor_record record)
    {
     
      UserConnector sqlConnector1 = new UserConnector();
      string sqlCommand1 = "INSERT INTO doctor_record(date_visiting, complaints, complication, number_medcard, id_doctor) VALUES " +
        "(@date_ , @complaints_ , @complicat , (select number_medcard from medcard where patient_id = (select patient_id from patient where username = @username)), " +
        "(SELECT id_doctor from doctor WHERE username=current_user)) returning id_doctor_record ;";
      NpgsqlCommand command1 = new NpgsqlCommand(sqlCommand1, sqlConnector1.GetConnection());
      command1.Parameters.AddWithValue("username", NpgsqlDbType.Text, record.Patient_Username);
      command1.Parameters.AddWithValue("date_", NpgsqlDbType.Date, DateTime.Parse(record.Date_Visiting));
      command1.Parameters.AddWithValue("complaints_", NpgsqlDbType.Text, record.Complaints);
      command1.Parameters.AddWithValue("complicat", NpgsqlDbType.Text, record.Complication);
      command1.Parameters.AddWithValue("username", NpgsqlDbType.Text, record.Patient_Username);
      command1.Parameters.AddWithValue("num", NpgsqlDbType.Integer, num);
     

      try
      {
        sqlConnector1.OpenConnection();
        NpgsqlDataReader reader1 = command1.ExecuteReader();
        while (reader1.Read()) { num = reader1.GetInt32(0); MessageBox.Show(num.ToString()); }
        sqlConnector1.CloseConnection();
      }
      catch (NpgsqlException ex) {/* MessageBox.Show(ex.Message);*/ }
    }

    public void CreateSickness(Sickness sickness, string username)
    {

      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = "insert into sickness(anamnez, cause, id_doctor_record) values(@anamnes, @cause, @num )";
          NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("anamnes", NpgsqlDbType.Text, sickness.Anamnes);
      command.Parameters.AddWithValue("cause", NpgsqlDbType.Text, sickness.Cause);
      command.Parameters.AddWithValue("num", NpgsqlDbType.Integer, num);


      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
      }
      catch (NpgsqlException ex) { 
       // MessageBox.Show(ex.Message); 
      }
      sqlConnector.CloseConnection();
    }

 

  }

}
