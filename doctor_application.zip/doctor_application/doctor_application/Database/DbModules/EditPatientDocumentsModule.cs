﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using Npgsql;
using NpgsqlTypes;

namespace doctor_application.Database.DbModules
{
    class EditPatientDocumentsModule
    {
    
    public void EditDocsPatient(Patient patient, string snils, string oms_num, string oms_seria, string ud_lich_num , string ud_lich_seria,
      string type)
    {
      UserConnector userConnector = new UserConnector();
      string sqlCommand = $"begin;" +
        $"update polis_oms set seria = @oms_seria where patient_id = @id;" +
        $"update polis_oms set number_oms = @oms_num where patient_id = @id;" +
        $"end;";
      string sqlCommand1 = $"begin;" +
        $"update patient set snils =@snils where patient_id = @id;" +
        $"end;";
      string sqlCommand2 = $"begin;" +
   $"update identification_document set number_ident_doc = @ud_num where patient_id = @id;" +
        $"update identification_document set seria = @ud_seria where patient_id = @id;" +
        $"update identification_document set type_document = @ud_type where patient_id = @id;" +
   $"end;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      NpgsqlCommand command1 = new NpgsqlCommand(sqlCommand1, userConnector.GetConnection());
      NpgsqlCommand command2 = new NpgsqlCommand(sqlCommand2, userConnector.GetConnection());
      command.Parameters.AddWithValue("oms_seria", NpgsqlDbType.Text,oms_seria);
      command.Parameters.AddWithValue("oms_num", NpgsqlDbType.Text, oms_num);
      command1.Parameters.AddWithValue("snils", NpgsqlDbType.Text, snils);
      command2.Parameters.AddWithValue("ud_num", NpgsqlDbType.Text, ud_lich_num);
      command2.Parameters.AddWithValue("ud_seria", NpgsqlDbType.Text, ud_lich_seria);
      command2.Parameters.AddWithValue("ud_type", NpgsqlDbType.Text, type);
      command1.Parameters.AddWithValue("id", NpgsqlDbType.Integer, patient.Patient_id);
      command2.Parameters.AddWithValue("id", NpgsqlDbType.Integer, patient.Patient_id);
      command.Parameters.AddWithValue("id", NpgsqlDbType.Integer, patient.Patient_id);

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        userConnector.CloseConnection();
      }
      catch (Exception e)
      {
        //MessageBox.Show(e.Message);
      }
      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader1 = command.ExecuteReader();
        userConnector.CloseConnection();
      }
      catch (Exception e)
      {
       // MessageBox.Show(e.Message);
      }
      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader2 = command.ExecuteReader();
        userConnector.CloseConnection();
      }
      catch (Exception e)
      {
       // MessageBox.Show(e.Message);
      }
    }
    }
}
