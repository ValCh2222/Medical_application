﻿using Npgsql;
using NpgsqlTypes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Xml.Linq;

namespace doctor_application.Database.DbModules
{
    internal class DrugModule
    {

    public int rec = 0;
    public int presc = 0;
    public void CreateDrug(string name, string dose, string way, string enume)
    {
   
      UserConnector sqlConnector1 = new UserConnector();
      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = "INSERT INTO drug(name_drug, dose_drug, way_using, enum, id_doctor_record) VALUES (@name, @dose, @way_using ,@enum, @num )";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("name", NpgsqlDbType.Text,name);
      command.Parameters.AddWithValue("dose", NpgsqlDbType.Text,dose);
      command.Parameters.AddWithValue("way_using", NpgsqlDbType.Text, way);
      command.Parameters.AddWithValue("enum", NpgsqlDbType.Text,enume);
      command.Parameters.AddWithValue("num", NpgsqlDbType.Integer, rec);

      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        sqlConnector.CloseConnection();
      }
      catch (NpgsqlException ex) { MessageBox.Show(ex.Message); }
    }

    public void CreatePrescription(string startdate, string validity)
    {
     


      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = "  insert into prescription(date_prescription, validity_period, id_doctor_record) " +
        "values(@start, @validity ,@num) returning id_prescription";
        

      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("start", NpgsqlDbType.Date, DateTime.Parse(startdate));
      command.Parameters.AddWithValue("validity", NpgsqlDbType.Date, DateTime.Parse(validity));
      command.Parameters.AddWithValue("num", NpgsqlDbType.Integer, rec);


      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        while (reader.Read()) { presc = reader.GetInt32(0); }
        sqlConnector.CloseConnection();
      }
      catch (NpgsqlException ex) { /*MessageBox.Show(ex.Message); */}
    }


    public void CreatePrescriptionDrug(string name, string dose, string way, string enums)
    {
    

      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = "  INSERT INTO drug(name_drug, dose_drug, way_using, enum, id_prescription) " +
        "VALUES(@name_drug , @dose_drug , @way_using , @enum_m, @num );";

      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("name_drug", NpgsqlDbType.Text,name );
      command.Parameters.AddWithValue("dose_drug", NpgsqlDbType.Text,dose );
      command.Parameters.AddWithValue("way_using", NpgsqlDbType.Text, way);
      command.Parameters.AddWithValue("enum_m", NpgsqlDbType.Text, enums);
      command.Parameters.AddWithValue("num", NpgsqlDbType.Integer, presc);

      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        sqlConnector.CloseConnection();
      }
      catch (NpgsqlException ex) { 
       // MessageBox.Show(ex.Message);
      }
    }


   
  }
}
