﻿using doctor_application.Database.DbEntities;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;

namespace doctor_application.Database.DbModules
{
    class AllergyDBModule
    {
    public List<Allergy> GetAllergiesListt()
    {
      List<Allergy> allergies = new List<Allergy>();
      UserConnector sqlConnector = new UserConnector();

      const string sqlCommand = "select * from get_all_allergies";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());

      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          allergies.Add(new Allergy(

              reader["name_of_allergy"].ToString()
          ));
        }
        sqlConnector.CloseConnection();
      }
      catch (Exception e)
      {
      }

      return allergies;
    }
  }
}
