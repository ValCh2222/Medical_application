﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using doctor_application.Database.DbEntities;
using doctor_application.pages;
using Npgsql;
using NpgsqlTypes;
using static System.Net.Mime.MediaTypeNames;

namespace doctor_application.Database.DbModules
{
    public class Doctor_module
    {
 
    public List<Doctor> GetDoctorListt()
    {
      List<Doctor> doctors = new List<Doctor>();
      UserConnector sqlConnector = new UserConnector();
      

      string sqlCommand = "select * from doctor d join speciality_doctor s on d.id_speciality = s.id_speciality";


      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());

      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          doctors.Add(new Doctor(
             
              reader["username"].ToString(),
              reader["first_name"].ToString(),
              reader["middle_name"].ToString(),
              reader["second_name"].ToString(),
              int.Parse(reader["experience"].ToString()),
              reader["education"].ToString(),
              reader["name"].ToString()
          ));
        }
        sqlConnector.CloseConnection();
      }
      catch (Exception e)
      {
        MessageBox.Show(e.Message);
      }

      return doctors;
    }

    public string GetType_Doctor(string username)
    {
      UserConnector sqlConnector = new UserConnector();
      string res = ""; string role = "";
      string sqlCommand = "select pos from doctor where username = @us";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand,sqlConnector.GetConnection());
      command.Parameters.AddWithValue("us", NpgsqlDbType.Text, username);

      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        while (reader.Read()) {  res = reader.GetString(0);  }
      }
      catch (Exception ex) { MessageBox.Show(ex.Message); }
      if (res == "1") { role = "glavvrach"; } if(res == "2") { role = "doctor"; }
      
      sqlConnector.SetRole(role);
      return role;
    }

    public bool UpdateDoctorInfo(string uesrnm, string first_nm, string middle_nm, string second_nm, int exp, 
                                  string educ, string specialization)
    {
      bool res = false;
      UserConnector sqlConnector = new UserConnector();
     const string sqlCommand = "UPDATE doctor SET first_name = @fn WHERE username = @usernm;" +
        "  UPDATE doctor SET second_name =  @snm WHERE username = @usernm;" +
        " UPDATE doctor SET middle_name = @mn WHERE username = @usernm;" +
        " UPDATE doctor SET experience = @exp WHERE username =@usernm;" +
        " UPDATE doctor SET education = @educ WHERE username = @usernm;" +
        " UPDATE doctor SET id_speciality = (select id_speciality from speciality_doctor WHERE name =  @speciality)" +
        " WHERE username = @usernm;";
        
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());

      command.Parameters.AddWithValue("usernm", NpgsqlDbType.Text, uesrnm);
      command.Parameters.AddWithValue("fn", NpgsqlDbType.Text, first_nm);
      command.Parameters.AddWithValue("mn", NpgsqlDbType.Text, middle_nm);
      command.Parameters.AddWithValue("snm", NpgsqlDbType.Text, second_nm);
      command.Parameters.AddWithValue("exp", NpgsqlDbType.Integer, exp);
      command.Parameters.AddWithValue("educ", NpgsqlDbType.Text, educ);
      command.Parameters.AddWithValue("speciality", NpgsqlDbType.Text, specialization);
      try
      {
        sqlConnector.OpenConnection();
        command.ExecuteNonQuery();
       // MessageBox.Show(uesrnm + " " + first_nm + " " + middle_nm + " " + second_nm + " " + exp.ToString() + " " + educ + " " + specialization);
        sqlConnector.CloseConnection();
        res = true;
        
      }
      catch (Exception e)
      {
        MessageBox.Show(e.Message);
      }
      return res;

    }


    public bool Create_Doctor(string fst_nm,string mle_nm,  string snd_nm, int exp, string ed ,string pos,  string usrnm,string pas, string spec  )
    {
      UserConnector sqlConnector = new UserConnector();
      const string sqlCommand = "call create_doctor(@fnm, @mnm, @sndnm, @exp, @ed, '2', @usr, @pas, @spec)";
      // 
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());

      command.Parameters.AddWithValue("fnm", fst_nm);
      command.Parameters.AddWithValue("mnm", mle_nm);
      command.Parameters.AddWithValue("sndnm", snd_nm);
      command.Parameters.AddWithValue("exp", exp);
      command.Parameters.AddWithValue("ed", ed);
      command.Parameters.AddWithValue("usr", usrnm);
      command.Parameters.AddWithValue("pas", pas);
      command.Parameters.AddWithValue("spec", spec);



      try
      {
        sqlConnector.OpenConnection();
        command.ExecuteNonQuery();
        sqlConnector.CloseConnection();
        return true;

      }
      catch (Exception e)
      {
       // MessageBox.Show(e.Message);
        return false;
      }
    }



    public Doctor Get_My_Acc()
    {

      UserConnector sqlConnector = new UserConnector();
      const string sqlCommand = "SELECT username, first_name,middle_name, second_name, experience ," +
        "(select  speciality_doctor.name from speciality_doctor where id_speciality= doctor.id_speciality)  as speciality," +
        "(select  find_role_doctor(current_user))  as role, education   FROM doctor where username=current_user ;";
      // 
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());

      sqlConnector.OpenConnection();
      NpgsqlDataReader reader = command.ExecuteReader();
      Doctor doc2 = new Doctor();

      while (reader.Read())
      {
        Doctor doc = new Doctor(

            reader["username"].ToString(),
            reader["first_name"].ToString(),
            reader["middle_name"].ToString(),
            reader["second_name"].ToString(),
            int.Parse(reader["experience"].ToString()),
            reader["education"].ToString(),
            reader["speciality"].ToString()
        );
        doc2 = doc;
      }
      sqlConnector.CloseConnection();
      return doc2;
    }


    public bool Update_My_username(string old_uesrnm, string new_username)
    {
      RegisterConnector registerConnector = new RegisterConnector();
      bool res = false;
      
      const string sqlCommand = "call edit_username_doctor(@old, @new)";
      // 
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, registerConnector.GetConnection());

      command.Parameters.AddWithValue("old", old_uesrnm);
      command.Parameters.AddWithValue("new", new_username);

      try
      {
        registerConnector.OpenConnection();
        command.ExecuteNonQuery();
        registerConnector.CloseConnection();
        res = true;

      }
      catch (Exception e)
      {
        MessageBox.Show(e.Message);

      }
      return res;
    }


  }
}
