﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using Npgsql;
using NpgsqlTypes;
using static System.Net.Mime.MediaTypeNames;

namespace doctor_application.Database.DbModules
{
  
    public class Diagnosis_DataBase_module
    {
    public int b = 0;


    public void CreateDiagnosis(Diagnosis d)
    {
      

      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = " INSERT INTO diagnosis(firstly_repeatedly_registered, main_disesase, related_diseases, id_doctor_record)" +
        " VALUES (@firstly," +
        " @main, @related, @num)";
      
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("main", NpgsqlDbType.Text, d.Main_disease );
      command.Parameters.AddWithValue("related", NpgsqlDbType.Text, d.Related_disease);
      command.Parameters.AddWithValue("firstly", NpgsqlDbType.Text, d.Firstly_repeatedly);
      command.Parameters.AddWithValue("num", NpgsqlDbType.Integer, b);
      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        sqlConnector.CloseConnection();
       // MessageBox.Show("diagnosis is ready");
      }
      catch (NpgsqlException ex) { /*MessageBox.Show(ex.Message);*/ }
      

    }


    public void CreateDisability(Sickness sickness, string username)
    {

      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = "INSERT INTO sickness(anamnez, cause, id_doctor_record) VALUES (@anamnes, @cause, @num );";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("anamnes", NpgsqlDbType.Text, sickness.Anamnes);
      command.Parameters.AddWithValue("cause", NpgsqlDbType.Text, sickness.Cause);
      command.Parameters.AddWithValue("num", NpgsqlDbType.Integer, b);


      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
      }
      catch (NpgsqlException ex) { /*MessageBox.Show(ex.Message); */}
    }
  }
}
