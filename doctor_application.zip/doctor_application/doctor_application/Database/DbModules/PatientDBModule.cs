﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls.Primitives;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using doctor_application.pages;
using Npgsql;
using NpgsqlTypes;

namespace doctor_application.Database.DbModules
{

  class PatientDBModule
  {
   private  UserConnector userConnector = new UserConnector();
    private MedcardModule medcardModule = new MedcardModule();
    //select * from patient p  join  medcard on p.patient_id = medcard.patient_id

    public List<String> GetListFIOUsernames()
    {
      List<String> patients = new List<String>();

      string sqlCommand = " SELECT username, (second_name || ' ' || first_name || ' ' || middle_name) as fio from patient;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          patients.Add(reader["fio"].ToString()+"  "+ "username:" + reader["username"].ToString());
        
        }     
      }
      catch(Exception ex) { /*MessageBox.Show(ex.Message);*/ }
      userConnector.CloseConnection();
      return patients;
    }

    public string GetCurrentFIO(string username)
    {
      string fio = "";
      string sqlCommand = "SELECT username, (second_name || ' ' || first_name || ' ' || middle_name) as fio from patient where username = @user ;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("user", NpgsqlDbType.Text,username);
      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
         fio =reader["fio"].ToString() + "  " + "username:" + reader["username"].ToString();

        }
        

      }
      catch (Exception ex) { /*MessageBox.Show(ex.Message);*/ }
      userConnector.CloseConnection();

      return fio;
    }


    public string GetLgota(string username)
    {
      string al = "";
      string sqlCommand = "  select name_lgota from lgota where id_lgota = \r\n(select id_lgota from patient where username =@us)";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("us", NpgsqlDbType.Text, username);

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          al = reader.GetValue(0).ToString();
        }

      }
      catch (Exception e)
      {
        MessageBox.Show("patient get all patients " + e.Message);
      }
      userConnector.CloseConnection();

      return al;
    }

    public string GetAllergy(string username)
    {
      string al = "";
      string sqlCommand = "  select name_of_allergy from allergy where id_allergy = \r\n(select id_allergy from patient where username =@us)";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("us", NpgsqlDbType.Text, username);

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          al = reader.GetValue(0).ToString();
        }

      }
      catch (Exception e)
      {
        MessageBox.Show("patient get all patients " + e.Message);
      }
      userConnector.CloseConnection();

      return al;
    }

    public string GetDisability(string username)
    {
      string al = "";
      string sqlCommand = "  select id_disability from patient where username =@us";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("us", NpgsqlDbType.Text, username);

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          al = reader.GetValue(0).ToString();
        }

      }
      catch (Exception e)
      {
        //MessageBox.Show("patient get all patients " + e.Message);
      }
      userConnector.CloseConnection();

      return al;
    }

    public List<Patient> GetListPatiens()
    {
      List<Patient> patients = new List<Patient>();
      string sqlCommand = "select * from medcard right join patient p on p.patient_id = medcard.patient_id;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          patients.Add(new Patient(
              reader["username"].ToString(),
              reader["first_name"].ToString(),
              reader["middle_name"].ToString(),
              reader["second_name"].ToString(),
              int.Parse(reader["patient_id"].ToString()),
               reader["date_birth"].ToString(),
              reader["sex"].ToString(),
                reader["phone_number"].ToString(),
               reader["blood_group"].ToString(),
               reader["rezus_factor"].ToString(),
               reader["group_health"].ToString(),
              reader["grazdanstvo"].ToString(),
          int.Parse(reader["number_medcard"].ToString()),
          reader["id_allergy"].ToString(),
            reader["snils"].ToString(),
            reader["id_disability"].ToString(),
            reader["id_lgota"].ToString()

          )); 
        }
        
      }
      catch (Exception e)
      {
       // MessageBox.Show("patient get all patients "+ e.Message);
      }
      userConnector.CloseConnection();

      return patients;
    }

                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      
    public void UpdatePatientHealthInfo(Patient patient, string group_health, string blood_group, string rezus, string al)
    {
      string sqlCommand = "call UpdateHealthOnfoPatient(@id_pat, @al, @blood, @rezus, @health) ";


      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("id_pat", NpgsqlDbType.Integer, patient.Patient_id);
      command.Parameters.AddWithValue("al", NpgsqlDbType.Integer, 374);
      command.Parameters.AddWithValue("blood", NpgsqlDbType.Integer, int.Parse(blood_group));
      command.Parameters.AddWithValue("rezus", NpgsqlDbType.Text, rezus);
      command.Parameters.AddWithValue("health", NpgsqlDbType.Integer,int.Parse(group_health));
      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
      }
      catch (NpgsqlException e)
      {
        //MessageBox.Show("update health info patient " + e.Message);
      }

      userConnector.CloseConnection();
    }



    public void UpdatePrivateInfoPatient(Patient patient, string date_birth, string fn, string mn, string sn, string sex, string phone)
    {

      string sqlCommand = "begin ; UPDATE patient  SET date_birth=@datebt WHERE patient_id=@id_pat;  " +
        "UPDATE patient  SET first_name =@fn  WHERE patient_id=@id_pat; " +
        " UPDATE patient  SET middle_name = @mn WHERE patient_id=@id_pat; " +
        " UPDATE patient  SET second_name=@sn WHERE patient_id=@id_pat; " +
        "UPDATE patient  SET sex=@sex WHERE patient_id=@id_pat; " +
        " UPDATE patient  SET phone_number=@tel WHERE patient_id=@id_pat;  end;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("id_pat", NpgsqlDbType.Integer, patient.Patient_id);
      command.Parameters.AddWithValue("datebt", NpgsqlDbType.Date, DateTime.Parse(date_birth));
      command.Parameters.AddWithValue("fn", NpgsqlDbType.Text, fn);
      command.Parameters.AddWithValue("mn", NpgsqlDbType.Text, mn);
      command.Parameters.AddWithValue("sn", NpgsqlDbType.Text, sn);
      command.Parameters.AddWithValue("sex", NpgsqlDbType.Text, sex);
      command.Parameters.AddWithValue("tel", NpgsqlDbType.Text, phone);
    


      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
      }
      catch (NpgsqlException e)
      {
       // MessageBox.Show("update_private_info " + e.Message);
      }

      userConnector.CloseConnection();
    }
    

    public bool CreatePatient(string first_name , string middle_name , string second_name, string date_birth ,
         string snils , string phone_number, string sex, string place_working , string blood_group, string rezus_factor,
       string group_health, string grazdanstvo, string username, string passwd)
    {
      
      string sqlCommand = "call CreatePatient( @first_nm , @middle_nm ,@second_nm, @date_b ,  @snils , @phone, @s, @placew, @blood,@rezus, @group_h, @grazd, @usernm, " +
      " @pass)";


      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("first_nm", NpgsqlDbType.Text, first_name);
      command.Parameters.AddWithValue("middle_nm", NpgsqlDbType.Text, middle_name);
      command.Parameters.AddWithValue("second_nm", NpgsqlDbType.Text, second_name);
      command.Parameters.AddWithValue("date_b", NpgsqlDbType.Date, DateTime.Parse(date_birth));
      command.Parameters.AddWithValue("snils", NpgsqlDbType.Text, snils);
      command.Parameters.AddWithValue("phone", NpgsqlDbType.Text, phone_number);
      command.Parameters.AddWithValue("s", NpgsqlDbType.Text, sex);
      command.Parameters.AddWithValue("placew", NpgsqlDbType.Text,place_working);
      command.Parameters.AddWithValue("blood", NpgsqlDbType.Integer,int.Parse(blood_group));
      command.Parameters.AddWithValue("rezus", NpgsqlDbType.Text, rezus_factor);
      command.Parameters.AddWithValue("group_h", NpgsqlDbType.Integer, int.Parse(group_health));
      command.Parameters.AddWithValue("grazd", NpgsqlDbType.Text, grazdanstvo);
      command.Parameters.AddWithValue("usernm", NpgsqlDbType.Text, username); 
      command.Parameters.AddWithValue("pass", NpgsqlDbType.Text, passwd);


      MessageBox.Show(command.CommandText);

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        userConnector.CloseConnection();
        string sql2 = "insert into agreement_proces_pers_data(name_med_org, date_agreement, patient_id ) values ('my organization', NOW(), (SELECT patient_id FROM patient  WHERE username  =@username));";
        
        NpgsqlCommand command2 = new NpgsqlCommand(sql2, userConnector.GetConnection());
        command2.Parameters.AddWithValue("username", NpgsqlDbType.Text, username);
        userConnector.OpenConnection();
        NpgsqlDataReader reader2 = command2.ExecuteReader();
        userConnector.CloseConnection();

        medcardModule.CreateMedcardPatientCreation(username);
        return true;
       
      }
      catch (NpgsqlException e)
      {
        //MessageBox.Show("create_patient " +  e.Message);
        return false;
      }
    
    }

    public bool CreateLgotaPatientCREATION(string username,string  lgota)
    {
      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = " UPDATE patient SET id_lgota =  (select id_lgota from lgota where name_lgota= @lgota ) WHERE username=@username;";
      //int id, string date, string complaints, string complications , int medcard_num, int id_doctor
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("username", NpgsqlDbType.Text, username);
      command.Parameters.AddWithValue("lgota", NpgsqlDbType.Text, lgota);
      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        sqlConnector.CloseConnection();
        return true;
      }

      catch (Exception e)
      {
        userConnector.CloseConnection();
       // MessageBox.Show("lgota creation problem:" + (e.Message));
        return false;
      }

      
    }


    public bool CreateDisabilityPatientCREATION(string username, string disability)
    {
      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = " UPDATE patient SET id_disability = (select id_disability from disability where group_disability= @dis) WHERE username=@username;";
      //int id, string date, string complaints, string complications , int medcard_num, int id_doctor
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("username", NpgsqlDbType.Text, username);
      command.Parameters.AddWithValue("dis", NpgsqlDbType.Integer, int.Parse(disability));
      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        sqlConnector.CloseConnection();
        return true;
      }

      catch (Exception e)
      {
        sqlConnector.CloseConnection();
        //MessageBox.Show("lgota creation problem: "+ e.Message);
        return false;
      }


    }


    public bool CreateAlergyPatientCREATION(string username, string allergy)
    {
      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = "UPDATE patient SET id_allergy =(select id_allergy from allergy where name_of_allergy= @al) WHERE username=@username;";
      //int id, string date, string complaints, string complications , int medcard_num, int id_doctor
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("username", NpgsqlDbType.Text, username);
      command.Parameters.AddWithValue("al", NpgsqlDbType.Integer, int.Parse(allergy));
      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        sqlConnector.CloseConnection();
        return true;
      }

      catch (Exception e)
      {
        sqlConnector.CloseConnection();
        //MessageBox.Show("allergy creation problem:" + e.Message);
        return false;
      }


    }



  }
}
