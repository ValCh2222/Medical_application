﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using doctor_application.pages;
using Npgsql;
using NpgsqlTypes;

namespace doctor_application.Database.DbModules
{
    class AuthentificationDocDbModule
    {
    private UserConnector userConnector = new UserConnector();


    public AuthentificationDoc GetAuthentificationDocPatient(Patient p)
    {
      AuthentificationDoc authentificationDoc = new AuthentificationDoc();
      string address = "";
      UserConnector userConnector = new UserConnector();
      string sqlCommand = "select * from identification_document where  patient_id = @id;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("id", NpgsqlDbType.Integer, p.Patient_id);

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          authentificationDoc.Id_identif_doc = int.Parse(reader["id_identif_doc"].ToString());
          authentificationDoc.Number_ident_doc = reader["number_ident_doc"].ToString();
          authentificationDoc.Seria = reader["seria"].ToString();
          authentificationDoc.Validity_period = reader["validity_period"].ToString();
          authentificationDoc.Type_Document = reader["type_document"].ToString();
          authentificationDoc.Patient_id = p.Patient_id;

        }

      }
      catch (Exception ex) { }
      return authentificationDoc;
    }

    public string GetNumSeriaAuthDoc(Patient p)
    {
      string auth_dock = "";
      UserConnector userConnector = new UserConnector();
      string sqlCommand = "select * from identification_document where  patient_id = @id;";
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, userConnector.GetConnection());
      command.Parameters.AddWithValue("id", NpgsqlDbType.Integer, p.Patient_id);

      try
      {
        userConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();

        while (reader.Read())
        {
          auth_dock += reader["seria"].ToString();
          auth_dock += " - ";
          auth_dock += reader["number_ident_doc"].ToString().ToString();
        }

      }
      catch (Exception ex) { }
      return auth_dock;
    }


    public bool CreateAuthDocPatientCreation(string username, string? seria, string num,  string type)
    {
      UserConnector sqlConnector = new UserConnector();
      string sqlCommand = "insert into identification_document(seria, number_ident_doc,  type_document, patient_id)VALUES(@seria,@num,@type,(select patient_id from patient where username =@username));";
      //int id, string date, string complaints, string complications , int medcard_num, int id_doctor
      NpgsqlCommand command = new NpgsqlCommand(sqlCommand, sqlConnector.GetConnection());
      command.Parameters.AddWithValue("seria", NpgsqlDbType.Text, (object)seria ?? DBNull.Value);
      command.Parameters.AddWithValue("num", NpgsqlDbType.Text, num);
      command.Parameters.AddWithValue("username", NpgsqlDbType.Text, username);
      command.Parameters.AddWithValue("type", NpgsqlDbType.Text, type);
      try
      {
        sqlConnector.OpenConnection();
        NpgsqlDataReader reader = command.ExecuteReader();
        sqlConnector.CloseConnection();
        return true;
      }

      catch (Exception e)
      {
        return false;
      }


    }
  }
}
