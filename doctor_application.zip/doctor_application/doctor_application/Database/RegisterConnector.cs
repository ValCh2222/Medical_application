﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace doctor_application.Database
{
    class RegisterConnector
  { 

    private const string _connectionStr = "Server=127.0.0.1;User Id=registrator_role;" +
        $"Password=registrator_01-;Database=cursovaya;";
  private readonly NpgsqlConnection _connection = new NpgsqlConnection(_connectionStr);


  public NpgsqlConnection GetConnection()
  {

    return _connection;
  }

  public void OpenConnection()
  {
    try
    {
      _connection.Open();
    }
    catch (NpgsqlException e)
    {

      MessageBox.Show(e.Message);
    }
  }

  public void CloseConnection()
  {
    try
    {
      _connection.Close();
    }
    catch (NpgsqlException e)
    {
      MessageBox.Show(e.Message);
    }
  }

}

 
}
