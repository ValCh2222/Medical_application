﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Windows;
using Npgsql;

namespace doctor_application.Database
{
    class AuthConnection
    {
    private static string _connectionStr = "Server=127.0.0.1;User Id=authentificator_role;" +
              "Password=aty))}fhdy%t-;Database=cursovaya;";
    private readonly NpgsqlConnection _connection = new NpgsqlConnection(_connectionStr);


    public NpgsqlConnection GetConnection()
    {

      return _connection;
    }

    public void OpenConnection()
    {
      try
      {
        _connection.Open();
      }
      catch (NpgsqlException e)
      {

        MessageBox.Show(e.Message);
      }
    }


    

    public void CloseConnection()
    {
      try
      {
        _connection.Close();
      }
      catch (NpgsqlException e)
      {
        MessageBox.Show(e.Message);
      }
    }

  }

 
}
