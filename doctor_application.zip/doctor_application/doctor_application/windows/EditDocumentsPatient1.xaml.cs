﻿using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using Npgsql.Internal.TypeHandlers.LTreeHandlers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace doctor_application.windows
{
    /// <summary>
    /// Логика взаимодействия для EditDocumentsPatient1.xaml
    /// </summary>
    public partial class EditDocumentsPatient1 : Window
    {
   
    private PlaceRegistrationDBModule PlaceRegistrationDBModule = new PlaceRegistrationDBModule();
    private EditPatientDocumentsModule EditPatientDocumentsModule = new EditPatientDocumentsModule();
    public Patient patient = new Patient();
    private AuthentificationDocDbModule dbModule= new AuthentificationDocDbModule();
    private PolisOMSModule oMSModule = new PolisOMSModule();  
    public Place_Registration place = new Place_Registration();
        public EditDocumentsPatient1() 
        {
            InitializeComponent();
        }
    private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
    {
      this.Hide();
    }

    public void GetInfo()
    {
     // MessageBox.Show(patient.Patient_id.ToString());
      place = PlaceRegistrationDBModule.GetPlaceRegPatientPlace(patient.Patient_id);
     
     try{ country_txt.Text = place.Country; } catch (Exception ex) { }
      try { district_txt.Text += place.District; } catch (Exception ex) { }
      try { locality_txt.Text += place.Locality; } catch (Exception ex) { }
      try { house_Number_txt.Text = place.House_Number.ToString(); } catch( Exception ex) { }
     try{ subiect_txt.Text = place.Subiect; } catch(Exception ex) { }
      try { street_txt.Text = place.Street; } catch(Exception ex) { }
 try{ city_txt.Text += place.City;} catch (Exception ex) { }
try{flat_number_txt.Text = place.Flat_number.ToString();} catch (Exception ex) { }
AuthentificationDoc a = dbModule.GetAuthentificationDocPatient(patient);
      doc_number_txt.Text = a.Number_ident_doc;
      doc_seria_txt.Text = a.Seria;
      type_doc_txt.Text = a.Type_Document;

      PolisOMS polisOMS = oMSModule.GetOMSPatient(patient);
      polis_OMS_seria_txt.Text = polisOMS.Seria;
      polis_OMS_number_txt.Text = polisOMS.Number;
      snils_txt.Text = patient.Snils;
      update_patient_health_btn.Click += UpdateDocsAddress;
    }

    private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }

    private void min_btn_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = WindowState.Minimized;
    }

    private void close_btn_Click(object sender, RoutedEventArgs e)
    {
      this.Hide();
    }


    private void UpdateDocsAddress(object sender, RoutedEventArgs e)
    {
      try
      {
        EditPatientDocumentsModule.EditDocsPatient(patient, snils_txt.Text, polis_OMS_number_txt.Text, polis_OMS_seria_txt.Text, doc_number_txt.Text,
    doc_seria_txt.Text,
  type_doc_txt.Text);
        PlaceRegistrationDBModule.EditPlaceRegPatient(patient.Patient_id, country_txt.Text,subiect_txt.Text, district_txt.Text,
          city_txt.Text, locality_txt.Text, street_txt.Text,house_Number_txt.Text, int.Parse(flat_number_txt.Text));
        attention_label.Foreground = Brushes.Green;
        attention_label.Content = "Информация успешно обновлена";
      }
      catch(Exception ex) {
        attention_label.Foreground = Brushes.Red;
        attention_label.Content =ex.Message;
      }
     
    }
  }
}
