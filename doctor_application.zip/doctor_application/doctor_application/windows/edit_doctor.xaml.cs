﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;

namespace doctor_application.windows
{
    /// <summary>
    /// Логика взаимодействия для edit_doctor.xaml
    /// </summary>
    public partial class edit_doctor : Window
    {
    private readonly Doctor _doctor;
    private readonly Doctor_module doctor_Module = new Doctor_module();
    private readonly SpecializaitonsModule specializaitonsModule = new SpecializaitonsModule();
    private edit_pas_username_window edit_Pas_Username_Window = new edit_pas_username_window();

    public edit_doctor()
    {
      InitializeComponent();
    
    }

    public edit_doctor(Doctor doctor)
    {
      InitializeComponent();
      _doctor = doctor;
      update_doc_btn.Click += UpdateDoc;
      LoadEditDoctor();

    }


    public void LoadEditDoctor()
    {


      if (MainWindow.role == "doctor")
      {
        edit_first_name_btn.Visibility = Visibility.Hidden;
        edit_user_info_btn.Visibility = Visibility.Hidden;
        edit_second_name_btn.Visibility = Visibility.Hidden;
        update_doc_btn.Visibility = Visibility.Hidden;
      }
      first_name_txt.Text = _doctor.First_name;
      second_name_txt.Text = _doctor.Second_name;
      middle_name_txt.Text = _doctor.Middle_name;
      experience_txt.Text = _doctor.Expirience.ToString();
      education_txt.Text = _doctor.Education;
      var a =specializaitonsModule.GetSpecializationListt();
      foreach(var b in a )
      {
        specialization_combobox.Items.Add(b.Specialization_Name);
        
      }
      specialization_combobox.SelectedValue = _doctor.Name_specialization;
      update_doc_btn.Click += UpdateDoc;
      edit_user_info_btn.Click += openEditUsrname;
 
    }
    private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
    {
      this.Hide();
    }

    private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }


        private void min_btn_Click(object sender, RoutedEventArgs e)
        {
      this.WindowState = WindowState.Minimized;
    }

        private void close_btn_Click(object sender, RoutedEventArgs e)
        {
      this.Hide();
    }

    private void UpdateDoc(object sender, RoutedEventArgs e)
    {
    bool res=  doctor_Module.UpdateDoctorInfo(_doctor.Username, first_name_txt.Text, middle_name_txt.Text, second_name_txt.Text,
        int.Parse(experience_txt.Text), education_txt.Text, specialization_combobox.SelectedValue.ToString());
      if(res == true)
      {
        attention_label.Foreground = Brushes.Green;
        attention_label.Content = "Информация успешно обновлена!";
      }
      if (res == false)
      {
        attention_label.Foreground = Brushes.Red;
        attention_label.Content = "Проверьте правильность введённых данных!";
      }

    }

    private void openEditUsrname(object sender, RoutedEventArgs e)
    {
      edit_Pas_Username_Window.old_username_txt.Text = _doctor.Username;
      edit_Pas_Username_Window.Show();
    }
  }
}
