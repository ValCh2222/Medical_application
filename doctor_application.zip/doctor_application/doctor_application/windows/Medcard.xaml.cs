﻿using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using doctor_application.Style;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using System.Reflection;

namespace doctor_application.windows
{
  /// <summary>
  /// Логика взаимодействия для Medcard.xaml
  /// </summary>
  /// 

  public partial class Medcard : Window
    {
    private PatientDBModule dBModule = new PatientDBModule();
    public string username_patient="";
    private Diagnosis_DataBase_module Diagnosis_Data = new Diagnosis_DataBase_module();
    private Doctor_module doctor_Module = new Doctor_module();
    private Doctor_Record_Creation creation = new Doctor_Record_Creation();
    private Doctor_record_db_module doctor_Record_Db_Module = new Doctor_record_db_module();
    public string num="";
        public Medcard()
        {
      
            InitializeComponent();
      add_doctor_record_btn.Click += Create_Record;
        }

    public void InsertListPatient()
    {
      
      List<string> strings = dBModule.GetListFIOUsernames();
      creation.patient_combobox.ItemsSource = strings;
      creation.patient_combobox.SelectedValue = dBModule.GetCurrentFIO(username_patient);
    }

    public void Create_Record(object sender, EventArgs e)
    {
      creation.Show();
    }

    public void ShowMedcardRecords()
    {
      //MessageBox.Show(num);
      DoctorsRecordsDataGrid.Items.Clear();
      User user = new User("hh", "hh", "glavvrach");
      List<Doctor_record> docrecs = doctor_Record_Db_Module.GetPatientDoctorRecords(num);

      foreach (var doctor in docrecs)
      {
        DoctorsRecordsDataGrid.Items.Add(doctor);
      }

      
     
    }

    public void InfoDoctor_Click(object sender, EventArgs e)
    {
      if (DoctorsRecordsDataGrid.SelectedIndex != -1)
      {
        var doctor = (Doctor_record)DoctorsRecordsDataGrid.SelectedItem;

        Doctor_record_window doctor_Record_Window = new Doctor_record_window();
        doctor_Record_Window.GetAllInfoDocRec(int.Parse(doctor.Id.ToString()));
        doctor_Record_Window.more_about_doc_btn.Click += InfoACcountDoctor_Click;
        doctor_Record_Window.Show();

      }

    }


    public void InfoACcountDoctor_Click(object sender, EventArgs e)
    {
      var doctor = (Doctor_record)DoctorsRecordsDataGrid.SelectedItem;
      List<Doctor> docs = doctor_Module.GetDoctorListt();
      Doctor current_doc = docs.Find(d => d.Username == doctor.Doctor_Username);
      edit_doctor edit_Doctor = new edit_doctor(current_doc);
      edit_Doctor.edit_first_name_btn.Visibility= Visibility.Hidden; edit_Doctor.edit_second_name_btn.Visibility = Visibility.Hidden;
      edit_Doctor.edit_user_info_btn.Visibility= Visibility.Hidden; edit_Doctor.update_doc_btn.Visibility = Visibility.Hidden;
      edit_Doctor.Show();
    }

    private void min_btn_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = WindowState.Minimized;
    }

    private void close_btn_Click(object sender, RoutedEventArgs e)
    {
      this.Hide();
    }


    private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }


    public void CreateNewDocRec(string username)
    {

    }
  }
}
