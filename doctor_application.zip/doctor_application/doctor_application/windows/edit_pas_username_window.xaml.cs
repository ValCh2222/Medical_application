﻿using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace doctor_application.windows
{
    /// <summary>
    /// Логика взаимодействия для edit_pas_username_window.xaml
    /// </summary>
    //
    public partial class edit_pas_username_window : Window
    {
    private readonly Doctor_module doctor_Module = new Doctor_module();
        public edit_pas_username_window()
        {
            InitializeComponent();
      update_username_btn.Click += Update;
        }
    private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
    {
      this.Hide();
    }

    private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }


    private void min_btn_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = WindowState.Minimized;
    }

    private void close_btn_Click(object sender, RoutedEventArgs e)
    {
      this.Hide();
    }

    private void Update(object sender, RoutedEventArgs e)
    {
      if (new_username_txt.Text.Length <2)
      {
        attention_label.Content = "введите новое имя пользователя";
      }
      if(new_username_txt.Text == old_username_txt.Text)
      {
        attention_label.Content = "старое и новое имена совпадают";
      }
      else
      {
        try
        {
          doctor_Module.Update_My_username(old_username_txt.Text, new_username_txt.Text);
          attention_label.Foreground = Brushes.Green;
          attention_label.Content = "Информация успешно обновлена";
          
        }
        catch(Exception ex) { }
        
      }
    }
  }
}
