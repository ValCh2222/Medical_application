﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;

namespace doctor_application.Style
{
    /// <summary>
    /// Логика взаимодействия для Doctor_record_window.xaml
    /// </summary>
    public partial class Doctor_record_window : Window
    {
        public Doctor_record_window()
        {
            InitializeComponent();
        }
    private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
    {
      this.Hide();
    }

    private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }


    private void min_btn_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = WindowState.Minimized;
    }

    private void close_btn_Click(object sender, RoutedEventArgs e)
    {
      this.Hide();
    }


    public void GetAllInfoDocRec(int num)
    {
      FullInfoDoctorRec_Module_DB fullInfoDoctorRec = new FullInfoDoctorRec_Module_DB();
      FullInfoDocRecord doctor_Record = fullInfoDoctorRec.GetFullInfo( num);
      fio_txt.Text =doctor_Record.FIO_patient ;
      date_txt.Text = doctor_Record.Date_Visiting;
      complaint_txt.Text = doctor_Record.Complaints;
      complication_txt.Text = doctor_Record.Complication;
      anamnes_txt.Text = doctor_Record.Anamnez;
      cause_txt.Text = doctor_Record.Cause;
      main_disease_txt.Text = doctor_Record.Main_Disease;
      firstly_secondly_txt.Text = doctor_Record.Firstly_Sec;
      second_disesase_txt.Text = doctor_Record.Second_Disease;
      drug_txt.Text = doctor_Record.Drug;
      drug_dose_txt.Text = doctor_Record.Drug_Dose;
      drug_usage_txt.Text = doctor_Record.Drug_Usage;
      enum_dose_txt.Text = doctor_Record.Enum_Dose;
      drug_recipe_txt.Text = doctor_Record.Drug_Recipe;
      drug_way_using_recipe_txt.Text = doctor_Record.Drug_Way_Using_Recipe;
      dates_recipe_txt.Text = doctor_Record.Dates_Recipe;
      enum_dose_recipe_txt.Text = doctor_Record.Drug_Dose_Recipe;
    }
  }
}
