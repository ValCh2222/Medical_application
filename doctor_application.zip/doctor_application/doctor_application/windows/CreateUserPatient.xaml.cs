﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using Npgsql;

namespace doctor_application.windows
{
    /// <summary>
    /// Логика взаимодействия для CreateUserPatient.xaml
    /// </summary>
    public partial class CreateUserPatient : Window
    {
    
    public Patient patient = new Patient();
    public Place_Registration _Registration = new Place_Registration();
    private PlaceRegistrationDBModule dBModule = new PlaceRegistrationDBModule();
    public PolisOMS polisOMS = new PolisOMS();
    private PolisOMSModule oMSModule = new PolisOMSModule();
    public AuthentificationDoc authentificationDoc = new AuthentificationDoc();
    
        public CreateUserPatient()
        {
            InitializeComponent();
      create_pat_btn.Click += create_btn_Click;
    
        }
    private void PackIcon_MouseDown(object sender, MouseButtonEventArgs e)
    {
      this.Hide();
    }

    private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
    {
      this.Hide();
    }
    private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }


    private void create_btn_Click(object sender, RoutedEventArgs e)
    {
      bool cool = false;
      PatientDBModule patientDBModule = new PatientDBModule();
      if (txt_password.Password.ToString() == txt_password2.Password.ToString())
      {
        try
        {
          patientDBModule.CreatePatient(patient.First_name, patient.Middle_name, patient.Second_name, patient.Date_Birth, patient.Snils,
       patient.Phone_number, patient.Patient_sex, "не указано", patient.Blood_group, patient.Rezus_factor, patient.Group_health,
       patient.Grazdanstvo, username_txt.Text, txt_password.Password.ToString());
          cool = true;
        } catch(NpgsqlException ex) { attention_label.Content = ex.Message; }

          if(cool == true)
        {
          try
          {
            AuthentificationDocDbModule authentificationDocDbModule = new AuthentificationDocDbModule();
            authentificationDocDbModule.CreateAuthDocPatientCreation(username_txt.Text, authentificationDoc.Seria, authentificationDoc.Number_ident_doc, authentificationDoc.Type_Document);

            MessageBox.Show("auth doc is ready");
          }
          catch (NpgsqlException ex) { attention_label.Content = ex.Message; }


          try { patientDBModule.CreateLgotaPatientCREATION(username_txt.Text, "0"); } catch (Exception ex) { } 
         try { patientDBModule.CreateDisabilityPatientCREATION(username_txt.Text, "0"); } catch (Exception ex) { } 
          try { patientDBModule.CreateAlergyPatientCREATION(username_txt.Text, "0"); } catch (Exception ex) { } 

          try
          {
            dBModule.CreatePlaceRegPatientCREATION(_Registration, username_txt.Text);
          }
          catch (NpgsqlException ex) { attention_label.Content = ex.Message; /*MessageBox.Show("place reg error:" + ex.Message);*/ }
          try
          {
            oMSModule.CreateOMSPatientCreation(username_txt.Text, polisOMS.Seria, polisOMS.Number);
          
          }
          catch (NpgsqlException ex) { attention_label.Content = ex.Message; }


        }
       
      }
      else
      {
        attention_label.Foreground = Brushes.Red;
        attention_label.Content = "пароли не совпадают!";
      }


    }


    private void min_btn_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = WindowState.Minimized;
    }

    private void close_btn_Click(object sender, RoutedEventArgs e)
    {
      this.Hide();
    }


    private void back_btn_Click(object sender, RoutedEventArgs e)
    {
      
      this.Hide();
    }
  }
}
