﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using doctor_application.pages;

namespace doctor_application.windows
{
    /// <summary>
    /// Логика взаимодействия для PatientCreationWindowxaml.xaml
    /// </summary>
    public partial class PatientCreationWindowxaml : Window
    {
 
    public Patient patient = new Patient();
    public Place_Registration _Registration = new Place_Registration();
    public PolisOMS polisOMS = new PolisOMS();
    public AuthentificationDoc authentificationDoc = new AuthentificationDoc();
    public CreateUserPatient userPatient = new CreateUserPatient();
    public PatientCreationWindowxaml()
        {
            InitializeComponent();
      continue_btn.Click += create_User_Patient_btn_Click;
    
    }
    private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
    {
      this.Hide();
    }

    private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }


    private void min_btn_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = WindowState.Minimized;
    }

    private void close_btn_Click(object sender, RoutedEventArgs e)
    {
      this.Hide();
    }


    private void create_User_Patient_btn_Click(object sender, RoutedEventArgs e)
    {
     
      patient.First_name = first_name_txt.Text; patient.Second_name = second_name_txt.Text; patient.Middle_name = middle_name_txt.Text;

      patient.Grazdanstvo = grazdanstvo_txt.Text; patient.Blood_group = blood_group_txt.Text; patient.Rezus_factor = rezus_txt.Text;
      patient.Phone_number = mobile_txt.Text; patient.Patient_sex = sex_txt.Text; patient.Date_Birth = date_birth_txt.Text;
      patient.Snils = snils_txt.Text;  patient.Group_health = group_zdorovia_txt.Text;

      _Registration.Country = country_txt.Text;
      _Registration.Subiect = subiect_txt.Text;
      _Registration.District = district_txt.Text;
      _Registration.City = city_txt.Text;
      _Registration.Locality = locality_txt.Text;
      _Registration.Street = street_txt.Text;
      _Registration.House_Number = house_Number_txt.Text;
      _Registration.Flat_number = flat_number_txt.Text;


      authentificationDoc.Number_ident_doc = doc_number_txt.Text;
      authentificationDoc.Seria = doc_seria_txt.Text;
      authentificationDoc.Type_Document = type_doc_txt.Text;


      polisOMS.Number = polis_OMS_number_txt.Text;
      polisOMS.Seria = polis_OMS_seria_txt.Text;

      userPatient.patient = patient;
      userPatient._Registration = _Registration; 
      userPatient.polisOMS = polisOMS;
      userPatient.authentificationDoc = authentificationDoc;


      userPatient.Show();
      this.Show();

    }
  }
}
