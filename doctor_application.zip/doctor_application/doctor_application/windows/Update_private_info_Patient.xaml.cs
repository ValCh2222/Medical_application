﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;

namespace doctor_application.windows
{
    /// <summary>
    /// Логика взаимодействия для Update_private_info_Patientxaml.xaml
    /// </summary>
    public partial class Update_private_info_Patientxaml : Window
    {
    public Patient patient;
    private PatientDBModule PatientDBModule = new PatientDBModule();
    public string lgota = "";
    public string dis = "";
        public Update_private_info_Patientxaml()
        {
            InitializeComponent();

      first_name_txt.Clear();
      second_name_txt.Text = string.Empty;
      middle_name_txt.Text = string.Empty; 
      date_birth_txt.Text = string.Empty;
      grazdanstvo_txt.Text = string.Empty;  
      mobile_txt.Text = string.Empty;

      attention_label.Content=string.Empty;
        }

    public void  SetInfoPatien()
    {
      update_patient_health_btn.Click += Update_Private_Info;
    }

    private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
    {
      this.Hide();
    }

    private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }
    private void min_btn_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = WindowState.Minimized;
    }

    private void close_btn_Click(object sender, RoutedEventArgs e)
    {
      this.Hide();
    }

    private void Update_Private_Info(object sender, RoutedEventArgs e)
    {
      
  
      try
      {
          PatientDBModule.UpdatePrivateInfoPatient(patient, date_birth_txt.Text, first_name_txt.Text, middle_name_txt.Text,
        second_name_txt.Text, sex_combobox.SelectedValue.ToString(), mobile_txt.Text);
     
        PatientDBModule.CreateLgotaPatientCREATION(patient.Username,lgota);
        PatientDBModule.CreateDisabilityPatientCREATION(patient.Username,dis);
        attention_label.Foreground = Brushes.Green;
        attention_label.Content = "Информация успешно обновлена";
      }
      catch(Exception ex) { }
     
      // first_name_txt.Text, middle_name_txt.Text, second_name_txt.Text,
      //sex_txt.Text,, int.Parse(disablity_txt.Text), int.Parse(lgota_txt.Text)
    }

  }
}
