﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;

namespace doctor_application.windows
{
    /// <summary>
    /// Логика взаимодействия для Create_dcotor.xaml
    /// </summary>
    /// 
   
    public partial class Create_dcotor : Window
    {
    private Doctor_module doctor_Module   = new Doctor_module();
        public Create_dcotor()
        {
            InitializeComponent();
        }

        private void PackIcon_MouseDown(object sender, MouseButtonEventArgs e)
        {
      this.WindowState=WindowState.Minimized;
        }

        private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
        {
      this.Hide();
    }

        private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
        {
          if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }



        private void create_doc_btn_Click(object sender, RoutedEventArgs e)
        {
      bool a = false;
      try
      {
        a = doctor_Module.Create_Doctor(first_name_txt.Text, middle_name_txt.Text, second_name_txt.Text, int.Parse(experience_txt.Text), education_txt.Text,
       "2", username_txt.Text, txt_password.Password.ToString(), specialization_combobox.SelectedValue.ToString());
      }
      catch (Exception ex) { }
     
      if (a==true)
      {
        attention_label.Foreground = Brushes.Green;
        attention_label.Content = "Врач успешно добавлен!";
      }
     else
      {
        attention_label.Foreground = Brushes.Red;
        attention_label.Content = "Проверьте введённые данные";
      }
    }
  }
}
