﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ExceptionServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;


namespace doctor_application.windows
{
    /// <summary>
    /// Логика взаимодействия для patient_profile_edit.xaml
    /// </summary>
    public partial class patient_profile_edit : Window
    {
    private Medcard medcard = new Medcard();
    private LgotaDBModule lgota= new LgotaDBModule();
    public Patient patient = new Patient();
    private PatientDBModule dBModule_pat = new PatientDBModule(); 
    private Update_private_info_Patientxaml update_Private_Info_Patientxaml = new Update_private_info_Patientxaml();  
    private PolisOMSModule oMSModule = new PolisOMSModule();
    private PlaceRegistrationDBModule PlaceRegdBModule = new PlaceRegistrationDBModule();
    private AuthentificationDocDbModule AuthentificationDocDbModule = new AuthentificationDocDbModule();
    private Update_health_info_patient update_Health_Info_Patient = new Update_health_info_patient();
    private AllergyDBModule AllergyDBModule = new AllergyDBModule();
    private Doctor_record_db_module doctor_Record_Db_ = new Doctor_record_db_module();
        public patient_profile_edit()
        {
            InitializeComponent();
     
          if(MainWindow.role =="doctor")
      {
        documents_stackpanel.Visibility= Visibility.Hidden;
        doc_seria_number_txt.Visibility= Visibility.Hidden;
        polis_OMS.Visibility= Visibility.Hidden;
        doc_seria_number_txt.Visibility = Visibility.Hidden;  
        mobile_txt.Visibility= Visibility.Hidden;
        snils_txt.Visibility= Visibility.Hidden;
        type_doc_txt.Visibility= Visibility.Hidden;
        docs_label.Visibility= Visibility.Hidden;
        address_txt.Visibility= Visibility.Hidden;
      }
        }

    public void SetMainInfoPatient()
    {
     // MessageBox.Show(patient.Username);
      update_Health_Info_Patient.al = dBModule_pat.GetAllergy(patient.Username);
      update_Private_Info_Patientxaml.dis = dBModule_pat.GetDisability(patient.Username);
      update_Private_Info_Patientxaml.lgota = dBModule_pat.GetLgota(patient.Username);
      
   
      if (MainWindow.role =="doctor")
      {
        heath_edit_btn.Visibility= Visibility.Hidden;
        main_info_edit_btn.Visibility = Visibility.Hidden;
        polis_OMS_edit_btn.Visibility = Visibility.Hidden;
      }

      medcard_btn.Click += ShowMedcard;
   


      first_name_txt.Text = patient.First_name;
      second_name_txt.Text = patient.Second_name;
      middle_name_txt.Text = patient.Middle_name;
      sex_txt.Text = patient.Patient_sex;
      date_birth_txt.Text = patient.Date_Birth;
      grazdanstvo_txt.Text = patient.Grazdanstvo;
      group_zdorovia_txt.Text = patient.Group_health;
      blood_group_txt.Text = patient.Blood_group + patient.Rezus_factor;
      snils_txt.Text = patient.Snils;

    

      GetPrivateInfoGlavvrach(patient);
      mobile_txt.Text = patient.Phone_number;
     

      polis_OMS_seria_number_txt.Text = oMSModule.GetNumSeriaOMS(patient);

      heath_edit_btn.Click += EditHealthInfoPat;
      main_info_edit_btn.Click += EditMaihInfoPat;
      polis_OMS_edit_btn.Click += edit_documents_patient;
      
     
    }


   

    private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
    {
      this.Hide();
    }

    private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }
    public void ShowMedcard(object sender, RoutedEventArgs e)
    {
      medcard.num = patient.Username;
      medcard.username_patient = patient.Username;
      medcard.InsertListPatient();
      medcard.ShowMedcardRecords();
      medcard.Show();
    }


    public void GetPrivateInfoGlavvrach(Patient p)
    {

      address_txt.Text = PlaceRegdBModule.GetPlaceRegPatient(p);

     AuthentificationDoc authentificationDoc = AuthentificationDocDbModule.GetAuthentificationDocPatient(p);
      type_doc_txt.Text = authentificationDoc.Type_Document;
      doc_seria_number_txt.Text = AuthentificationDocDbModule.GetNumSeriaAuthDoc(p);
      PolisOMS polisOMS = oMSModule.GetOMSPatient(patient);
      polis_OMS_seria_number_txt.Text = polisOMS.Seria + " " + polisOMS.Number;
      snils_txt.Text = patient.Snils;


    }


   public void EditHealthInfoPat(object sender, RoutedEventArgs e)
    {
    
      update_Health_Info_Patient.patient = patient;
      update_Health_Info_Patient.group_txt.Text = group_zdorovia_txt.Text;
      update_Health_Info_Patient.SetHealthInfo();
      
      update_Health_Info_Patient.Show();
    }


    private void EditMaihInfoPat(object sender, RoutedEventArgs e)
    {
      
      update_Private_Info_Patientxaml.date_birth_txt.Text = date_birth_txt.Text;
      update_Private_Info_Patientxaml.first_name_txt.Text = first_name_txt.Text;
      update_Private_Info_Patientxaml.middle_name_txt.Text = middle_name_txt.Text;
      update_Private_Info_Patientxaml.second_name_txt.Text = second_name_txt.Text;
      update_Private_Info_Patientxaml.sex_combobox.SelectedValue = patient.Patient_sex;
      update_Private_Info_Patientxaml.mobile_txt.Text = patient.Phone_number;
      update_Private_Info_Patientxaml.grazdanstvo_txt.Text = grazdanstvo_txt.Text;
      update_Private_Info_Patientxaml.patient = patient;
      update_Private_Info_Patientxaml.SetInfoPatien();
      update_Private_Info_Patientxaml.Show();
    }


    private void edit_documents_patient(object sender, RoutedEventArgs e)
    {
      EditDocumentsPatient1 editDocumentsPatient1 = new EditDocumentsPatient1();
      editDocumentsPatient1.patient = patient;
      editDocumentsPatient1.GetInfo();
      editDocumentsPatient1.Show();
    }



    private void min_btn_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = WindowState.Minimized;
    }

    private void close_btn_Click(object sender, RoutedEventArgs e)
    {
      this.Hide();
    }
  }
}
