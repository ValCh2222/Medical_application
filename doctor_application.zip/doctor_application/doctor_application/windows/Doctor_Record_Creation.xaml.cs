﻿using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace doctor_application.windows
{
    /// <summary>
    /// Логика взаимодействия для Doctor_Record_Creation.xaml
    /// </summary>
    public partial class Doctor_Record_Creation : Window
    {
    private PatientDBModule dBModule = new PatientDBModule();
    private Doctor_record_db_module doctor_Record_Db_ = new Doctor_record_db_module();
    private Diagnosis_DataBase_module Diagnosis_Data = new Diagnosis_DataBase_module();
    private bool disease = false;
    private bool drug = false;
    private bool recipe = false;
    public Doctor_Record_Creation()
    {
      


      InitializeComponent();
      

      create_btn.Click += Create_Click;


      disease_checkbox.Checked += ComboboxDiseaseChecked;
      disease_checkbox.Unchecked += ComboboxDiseaseUnChecked;

      drug_checkbox.Checked += ComboboxDrugChecked;
      drug_checkbox.Unchecked += ComboboxDrugUnChecked;

      drug_recipe_checkbox.Checked += ComboboxRecipeChecked;
      drug_recipe_checkbox.Unchecked += ComboboxRecipeUnChecked;
    }

    public void InsertListPatient()
    {
      List<string> strings = dBModule.GetListFIOUsernames();
      patient_combobox.ItemsSource = strings;
    }


    private void Create_Click(object sender, RoutedEventArgs e)
    {
      string username = patient_combobox.SelectedValue.ToString();
      int pos = username.LastIndexOf(':');
      string bbb = username.Substring(pos+1).Trim();
     // MessageBox.Show(bbb);
      Doctor_record doctor_Record = new Doctor_record(date_txt.Text, complaint_txt.Text, complication_txt.Text, bbb);
      DrugModule drugModule = new DrugModule();

      try
      {
        Sickness sickness = new Sickness(anamnes_txt.Text, cause_txt.Text);
        doctor_Record_Db_.CreateDoctorRecord(doctor_Record);
        Diagnosis_Data.b = doctor_Record_Db_.num;
        drugModule.rec = doctor_Record_Db_.num;
        if(disease ==true)
        {
          Diagnosis diagnosis = new Diagnosis(firstly_secondly_txt.Text, main_disease_txt.Text, second_disesase_txt.Text);
          Diagnosis_Data.CreateDiagnosis(diagnosis);
          doctor_Record_Db_.CreateSickness(sickness, bbb);

        }

        System.Threading.Thread.Sleep(300);

        if (drug ==true)
        {
          
          drugModule.CreateDrug(drug_txt.Text, drug_dose_txt.Text, drug_way_using_recipe_txt.Text, enum_dose_txt.Text) ;
        }

        if(recipe==true) 
        {
          drugModule.CreatePrescription(dates_start_txt.Text, dates_end_txt.Text);
          drugModule.CreatePrescriptionDrug(drug_recipe_txt.Text,drug_dose_recipe_txt.Text, drug_way_using_recipe_txt.Text, enum_dose_recipe_txt.Text);

        }
        attention_label.Foreground = Brushes.Green;
        attention_label.Content = "успешно добавлены записи";
      }
      catch(NpgsqlException ex) { attention_label.Foreground = Brushes.Red; attention_label.Content = ex.Message; }
      


      
    }

    private void ComboboxDiseaseChecked(object sender, RoutedEventArgs e)
    {
      disease = true;
    }
    private void ComboboxDiseaseUnChecked(object sender, RoutedEventArgs e)
    {
disease= false;
    }

    private void ComboboxDrugChecked(object sender, RoutedEventArgs e)
    {
      drug = true;
    }
    private void ComboboxDrugUnChecked(object sender, RoutedEventArgs e)
    {
      drug = false;
    }


    private void ComboboxRecipeChecked(object sender, RoutedEventArgs e)
    {
      recipe = true;
    }
    private void ComboboxRecipeUnChecked(object sender, RoutedEventArgs e)
    {
     recipe = false;
    }


    private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
    {
      this.Hide();
    }

    private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }


    private void min_btn_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = WindowState.Minimized;
    }

    private void close_btn_Click(object sender, RoutedEventArgs e)
    {
      this.Hide();
    }


  }
}
