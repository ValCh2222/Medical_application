﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using Npgsql;

namespace doctor_application.windows
{
  /// <summary>
  /// Логика взаимодействия для Update_health_info_patient.xaml
  /// </summary>
  /// 
 
    public partial class Update_health_info_patient : Window
    {
    public string al = "";
    public Patient patient = new Patient();
    private PatientDBModule dBModule = new PatientDBModule();
        public Update_health_info_patient()
        {
      
            InitializeComponent();
      update_patient_health_btn.Click += update_btn_Click;
        }


    private void update_btn_Click(object sender, RoutedEventArgs e)
    {
      
      try
      {
        
        dBModule.UpdatePatientHealthInfo(patient, group_txt.Text, blood_group_txt.Text, rezus_factor_txt.Text,al);
        attention_label.Foreground = Brushes.Green;
        attention_label.Content = "данные успешно обновлены";

      }
      catch (NpgsqlException ex)
      {
        attention_label.Foreground = Brushes.Red;
        attention_label.Content = ex.Message;
      }
    }


    public void SetHealthInfo()
    {
      blood_group_txt.Text = patient.Blood_group;
      group_txt.Text = patient.Group_health;
      rezus_factor_txt.Text += patient.Rezus_factor;
        
    }
  
    private void PackIcon_MouseDown_1(object sender, MouseButtonEventArgs e)
    {
      this.Hide();
    }

    private void StackPanel_MouseDown(object sender, MouseButtonEventArgs e)
    {
      if (e.ChangedButton == MouseButton.Left)
      {
        this.DragMove();
      }
    }


    private void min_btn_Click(object sender, RoutedEventArgs e)
    {
      this.WindowState = WindowState.Minimized;
    }

    private void close_btn_Click(object sender, RoutedEventArgs e)
    {
      this.Hide();
    }
  }
}
