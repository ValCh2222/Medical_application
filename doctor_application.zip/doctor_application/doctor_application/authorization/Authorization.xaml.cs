﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using doctor_application.Database;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;

namespace doctor_application
{
    /// <summary>
    /// Логика взаимодействия для Authorization.xaml
    /// </summary>
    /// 
    public partial class Authorization : Window
    {
   
    AuthorizationModule authorizationModule = new AuthorizationModule();
        public Authorization()
        {
            InitializeComponent();
      
      login_btn.Click += CheckAuth1;
        }

    public void CheckAuth1(object sender, RoutedEventArgs e)
    {
      bool a =CheckAuth(txt_username.Text, txt_password.Password.ToString());
      if (a == true)
      {
        string connection_string = $"Server=127.0.0.1;User Id={txt_username.Text};" +
             $"Password={txt_password.Password};Database=cursovaya;";
        MainWindow mainWindow = new MainWindow(connection_string);
        mainWindow.username_txt.Text = txt_username.Text;
        MainWindow.connectionString = connection_string;

        Doctor_module doctor_Module = new Doctor_module();
        MainWindow.role = doctor_Module.GetType_Doctor(txt_username.Text);

        mainWindow.Show();
        Close();
      }
      else
      {
        attention_label.Content = "Ошибка! Проверьте корректность введённых данных";
      }
     
    }

    public bool CheckAuth(string username, string password)
    {
      return authorizationModule.CheckAuthorization(username, password);
    }

    }
}
