﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using doctor_application.pages;
using doctor_application.Style;
using doctor_application.windows;
using Npgsql;
using NpgsqlTypes;

namespace doctor_application.pages
{
    /// <summary>
    /// Логика взаимодействия для doctor_records_info.xaml
    /// </summary>
    /// 
    
    public partial class doctor_records_info : Page
    {
    Doctor_module doctor_Module = new Doctor_module();
    Doctor_record_db_module doctor_Record_Db_Module = new Doctor_record_db_module();
    Doctor_Record_Creation _Creation = new Doctor_Record_Creation();
        public doctor_records_info()
        {
            InitializeComponent();
   
    }


    public void Show_Doc_Records()
    {
      DoctorsRecordsDataGrid.Items.Clear();
      List <Doctor_record> docrecs = doctor_Record_Db_Module.GetDoctorRecordsList();
      
      foreach (var doctor in docrecs)
      {
        DoctorsRecordsDataGrid.Items.Add(doctor);
      }

      add_doctor_record_btn.Click += Create_Doctor_Record_Click;
    }

    public void Create_Doctor_Record_Click(object sender, EventArgs e)
    {
      _Creation.InsertListPatient();
      _Creation.Show();
    }

      public void InfoDoctor_Click(object sender, EventArgs e)
    {
      if (DoctorsRecordsDataGrid.SelectedIndex != -1)
      {
        var doctor = (Doctor_record)DoctorsRecordsDataGrid.SelectedItem;
        
        Doctor_record_window doctor_Record_Window = new Doctor_record_window();
        doctor_Record_Window.GetAllInfoDocRec(int.Parse(doctor.Id.ToString()));
        doctor_Record_Window.more_about_doc_btn.Click += InfoACcountDoctor_Click;
        doctor_Record_Window.Show();

      }

    

    }

    public void InfoACcountDoctor_Click(object sender, EventArgs e)
    {
      var doctor = (Doctor_record)DoctorsRecordsDataGrid.SelectedItem;
      List<Doctor> docs = doctor_Module.GetDoctorListt();
      Doctor current_doc = docs.Find(d => d.Username == doctor.Doctor_Username);
      edit_doctor edit_Doctor = new edit_doctor(current_doc);
      edit_Doctor.Show();
    }


  }
}
