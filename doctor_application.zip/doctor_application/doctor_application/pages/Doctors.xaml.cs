﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using doctor_application.windows;

namespace doctor_application.pages
{
  /// <summary>
  /// Логика взаимодействия для Doctors.xaml
  /// </summary>

  public partial class Doctors : Page
  {
    private Create_dcotor create_Dcotor = new Create_dcotor();
    private Doctor_module doctor_Module = new Doctor_module();
    private readonly SpecializaitonsModule specializaitonsModule = new SpecializaitonsModule();

    public Doctors()
    {
      InitializeComponent();
      if (MainWindow.role == "doctor")
      {
        add_doctor_btn.Visibility = Visibility.Hidden;
      }
      else
      {
        add_doctor_btn.Click += CreateDoctor_Click;
      }
     


    }
    public void Get_All_Doctors()
    {
      DoctorsDataGrid.Items.Clear();
      List<Doctor> doctors = doctor_Module.GetDoctorListt();
      foreach (var doctor in doctors)
      {
        DoctorsDataGrid.Items.Add(doctor);
      }
    }
    private void InfoDoctor_Click(object sender, RoutedEventArgs e)
    {
      if (DoctorsDataGrid.SelectedIndex != -1)
      {
        var doctor = (Doctor)DoctorsDataGrid.SelectedItem;

        edit_doctor edit_Doctor = new edit_doctor(doctor);
        edit_Doctor.LoadEditDoctor();
        edit_Doctor.Show();

      }
    }

    private void CreateDoctor_Click(object sender, RoutedEventArgs e)
    {
      var a = specializaitonsModule.GetSpecializationListt();
      foreach (var b in a)
      {
        create_Dcotor.specialization_combobox.Items.Add(b.Specialization_Name);

      }
      create_Dcotor.Show();
    }
  }
}
