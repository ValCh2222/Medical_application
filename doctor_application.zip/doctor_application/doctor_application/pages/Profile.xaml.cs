﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using doctor_application.windows;

namespace doctor_application.pages
{
  /// <summary>
  /// Логика взаимодействия для Profile.xaml
  /// </summary>
  
    public partial class Profile : Page
    {
    private edit_doctor Edit_Doctor = new edit_doctor();
    public static Doctor_module doctor_Module = new Doctor_module();
    private edit_pas_username_window edit_Pas_Username_Window = new edit_pas_username_window();
    
    SpecializaitonsModule specializaitonsModule = new SpecializaitonsModule();
    public Profile()
        {

      
      InitializeComponent();
      if (MainWindow.role == "doctor")
      {
        edit_btn.Visibility = Visibility.Hidden;
      }
      GetMyAcc();
      edit_btn.Click += EditMyAcc;
      edit_Pas_Username_Window.update_username_btn.Click += UpdateMyUSRN;
        }


       public void  GetMyAcc()
    {
      Doctor _doctor = doctor_Module.Get_My_Acc();
      first_name_label.Content = _doctor.First_name;
      second_name_label.Content= _doctor.Second_name;
      middle_name_label.Content = _doctor.Middle_name;
      specialization_label.Content = _doctor.Name_specialization;
      education_textbox.Text = _doctor.Education;
      experience_label.Content = _doctor.Expirience.ToString();


      

    }

    public void EditMyAcc(object sender, RoutedEventArgs e)
    {
      Doctor _doctor = doctor_Module.Get_My_Acc();
      Edit_Doctor.first_name_txt.Text = _doctor.First_name;
      Edit_Doctor.second_name_txt.Text = _doctor.Second_name;
      Edit_Doctor.middle_name_txt.Text = _doctor.Middle_name;
      Edit_Doctor.experience_txt.Text = _doctor.Expirience.ToString();
      Edit_Doctor.education_txt.Text = _doctor.Education;
      var a = specializaitonsModule.GetSpecializationListt();
      foreach (var b in a)
      {
        Edit_Doctor.specialization_combobox.Items.Add(b.Specialization_Name);

      }
      Edit_Doctor.specialization_combobox.SelectedValue = _doctor.Name_specialization;
      Edit_Doctor.update_doc_btn.Click += UpdateDoc;
      Edit_Doctor.edit_user_info_btn.Click += openEditUsrname;
      Edit_Doctor.Show();
    }
    private void UpdateDoc(object sender, RoutedEventArgs e)
    {
      Doctor _doctor = doctor_Module.Get_My_Acc();
      bool res = doctor_Module.UpdateDoctorInfo(_doctor.Username, Edit_Doctor.first_name_txt.Text, Edit_Doctor.middle_name_txt.Text, Edit_Doctor.second_name_txt.Text,
          int.Parse(Edit_Doctor.experience_txt.Text), Edit_Doctor.education_txt.Text, Edit_Doctor.specialization_combobox.SelectedValue.ToString());
      if (res == true)
      {
        Edit_Doctor.attention_label.Foreground = Brushes.Green;
        Edit_Doctor.attention_label.Content = "Информация успешно обновлена!";
      }
      if (res == false)
      {
        Edit_Doctor.attention_label.Foreground = Brushes.Red;
        Edit_Doctor.attention_label.Content = "Проверьте правильность введённых данных!";
      }

    }

    private void openEditUsrname(object sender, RoutedEventArgs e)
    {
      Doctor _doctor = doctor_Module.Get_My_Acc();
      edit_Pas_Username_Window.old_username_txt.Text = _doctor.Username;
      edit_Pas_Username_Window.Show();
    }

    private void UpdateMyUSRN(object sender, RoutedEventArgs e)
    {
      doctor_Module.Update_My_username(edit_Pas_Username_Window.old_username_txt.Text, edit_Pas_Username_Window.new_username_txt.Text);
    }


  }
}
