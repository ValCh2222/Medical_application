﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using doctor_application.Database.DbEntities;
using doctor_application.Database.DbModules;
using doctor_application.windows;

namespace doctor_application.pages
{
    /// <summary>
    /// Логика взаимодействия для Patients_Page.xaml
    /// </summary>
    public partial class Patients_Page : Page
    {
    private PatientCreationWindowxaml PatientCreationWindowxaml = new PatientCreationWindowxaml();
    PatientDBModule PatientDBModule = new PatientDBModule();
    private patient_profile_edit patient_Profile_ = new patient_profile_edit();
    private AllergyDBModule allergy = new AllergyDBModule();
        public Patients_Page()
        {
            InitializeComponent();
      add_patient_btn.Click += CreatePatient_Click;
    }

    public void Get_All_Patients()
    {
      if(MainWindow.role =="doctor")
      {
        add_patient_btn.Visibility = Visibility.Hidden;
      }
      PatientsDataGrid.Items.Clear();
      List<Patient> patients = PatientDBModule.GetListPatiens();
      foreach (var patient in patients)
      {
        PatientsDataGrid.Items.Add(patient);
      }
    }

        private void InfoPatient_Click(object sender, RoutedEventArgs e)
        {
      
      var patient = (Patient)PatientsDataGrid.SelectedItem;
      AddAllergiesToList();
      patient_Profile_.patient = patient;
      patient_Profile_.SetMainInfoPatient();
      patient_Profile_.Show();
      patient_Profile_.GetPrivateInfoGlavvrach(patient);
      
    }


    private void AddAllergiesToList()
    {
    
    }

    private void CreatePatient_Click(object sender, RoutedEventArgs e)
    {
      
      PatientCreationWindowxaml.Show();
     
    }

    }
  }
